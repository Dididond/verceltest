// Maps catalog cards to slim listing items. Shared by the prebuild step
// (scripts/build-items.mjs) and src/lib/data/catalog.ts, so there is one
// definition of an item.
const STORE_IMG = "https://banners.pluginboutique.com/";

/** @param {any} c card  @param {Record<string, number[]>} manifest mirrored images */
export function toItem(c, manifest) {
  const p = c.product;
  const id = p.image_url && p.image_url.startsWith(STORE_IMG) ? p.image_url.slice(STORE_IMG.length).split(/[/?#]/)[0] || null : null;
  const img = id ? manifest[id] : undefined;
  return {
    n: p.name, p: c.path, d: c.developer.name, dp: c.developer.path, t: p.product_type,
    c: c.category.label, cp: c.category.path, s: p.subcategory, r: p.requires,
    f: p.formats, o: p.os, im: img ? id : null, iw: img ? img[0] : 0, ih: img ? img[1] : 0,
    rt: c.store.rating, rc: Math.round(c.store.rating_count ?? 0), tr: p.has_trial,
  };
}

/** Most-reviewed first, then best rated: the default "relevance". */
export const byPopularity = (a, b) => b.rc - a.rc || (b.rt ?? 0) - (a.rt ?? 0) || a.n.localeCompare(b.n);

/**
 * @returns {{ items: any[], extra: any[] }} items: indexable cards, by popularity;
 *   extra: noindex cards (flagged, upgrade/crossgrade), needed for related links.
 */
export function buildItems(cards, manifest) {
  const items = [], extra = [];
  for (const c of cards) (c.indexable ? items : extra).push(toItem(c, manifest));
  items.sort(byPopularity);
  return { items, extra };
}
