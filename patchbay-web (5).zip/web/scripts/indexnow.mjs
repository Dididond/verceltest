#!/usr/bin/env node
/**
 * Submits site URLs to IndexNow (Bing, Yandex, Seznam, Naver) so new and
 * changed pages are crawled within hours instead of weeks.
 *
 *   INDEXNOW_KEY=<key> node scripts/indexnow.mjs                  # every URL in the live sitemaps
 *   INDEXNOW_KEY=<key> node scripts/indexnow.mjs /plugins/a /presets/b   # only these paths
 *   ... --site https://pluginhood.com --dry-run
 *
 * The same INDEXNOW_KEY must be set on the deployed site, which serves it at
 * /indexnow.txt. Run after each deploy that adds or changes products.
 */
const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf("--" + n); return i < 0 ? d : args.splice(i, 2)[1]; };
const site = (opt("site", process.env.NEXT_PUBLIC_SITE_URL || "https://pluginhood.com")).replace(/\/$/, "");
const dry = args.includes("--dry-run") && args.splice(args.indexOf("--dry-run"), 1);
const key = process.env.INDEXNOW_KEY;
if (!key) { console.error("Set INDEXNOW_KEY"); process.exit(1); }

const locs = (xml) => [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1].replace(/&amp;/g, "&"));
let urls;
if (args.length) {
  urls = args.map((p) => (p.startsWith("http") ? p : site + p));
} else {
  const index = await (await fetch(`${site}/sitemap.xml`)).text();
  urls = [];
  // Child sitemaps are listed with the canonical origin; fetch them from --site.
  for (const sm of locs(index)) urls.push(...locs(await (await fetch(sm.replace(/^https?:\/\/[^/]+/, site))).text()).filter((u) => !u.includes("/product-images/")));
}
// Submitted URLs keep the canonical host from the sitemap.
const host = new URL(urls[0] ?? site).host;
console.log(`${urls.length} URLs for ${host}${dry ? " (dry run)" : ""}`);
for (let i = 0; i < urls.length; i += 10000) {
  const urlList = urls.slice(i, i + 10000);
  if (dry) { console.log(`  batch ${i / 10000 + 1}: ${urlList.length} URLs, e.g. ${urlList[0]}`); continue; }
  const res = await fetch("https://api.indexnow.org/indexnow", {
    method: "POST",
    headers: { "content-type": "application/json; charset=utf-8" },
    body: JSON.stringify({ host, key, keyLocation: `${site}/indexnow.txt`, urlList }),
  });
  console.log(`  batch ${i / 10000 + 1}: ${urlList.length} URLs → HTTP ${res.status}`);
  if (res.status >= 400) { console.log(await res.text()); process.exitCode = 1; }
}
