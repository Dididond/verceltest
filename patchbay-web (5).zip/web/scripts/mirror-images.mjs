#!/usr/bin/env node
/**
 * Mirrors every product.image_url from data/catalog_seo.json.gz into our own
 * storage as WebP, so the site never hotlinks the store's CDN.
 *
 * For each unique image it writes two files:
 *   <id>.webp      max 1200px wide (product hero, og:image)
 *   <id>-480.webp  480px wide      (cards)
 * and records the real width/height in data/images.json, which the site reads
 * at build time. Images already in the manifest are skipped, so re-running only
 * fetches new products.
 *
 * Usage
 *   node scripts/mirror-images.mjs                      # files -> public/product-images
 *   node scripts/mirror-images.mjs --upload             # also upload to S3-compatible storage (R2)
 *   node scripts/mirror-images.mjs --limit 20           # try a few first
 *
 * Options
 *   --out <dir>           local output dir (default public/product-images)
 *   --concurrency <n>     parallel downloads (default 6)
 *   --limit <n>           only process the first n missing images
 *   --upload              upload each file to the bucket after converting
 *   --source-origin <url> fetch from another origin instead of the store CDN (testing)
 *
 * Upload env (Cloudflare R2 or any S3 API)
 *   S3_ENDPOINT           e.g. https://<account-id>.r2.cloudflarestorage.com
 *   S3_BUCKET             bucket name
 *   S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY
 *   S3_PREFIX             optional key prefix (default "p/")
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";
import sharp from "sharp";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CATALOG = path.join(ROOT, "data", "catalog_seo.json.gz");
const MANIFEST = path.join(ROOT, "data", "images.json");
const MAX_W = 1200, CARD_W = 480, QUALITY = 80;

const args = process.argv.slice(2);
const opt = (name, def) => { const i = args.indexOf("--" + name); return i < 0 ? def : args[i + 1]; };
const flag = (name) => args.includes("--" + name);
const OUT = path.resolve(ROOT, opt("out", "public/product-images"));
const CONCURRENCY = +opt("concurrency", 6);
const LIMIT = +opt("limit", Infinity);
const SOURCE = opt("source-origin", null);
const UPLOAD = flag("upload");

// ---------- Manifest: { "<id>": [width, height, bytes, uploaded(0|1)] } ----------
const manifest = existsSync(MANIFEST) ? JSON.parse(readFileSync(MANIFEST, "utf8")) : {};
let dirty = 0;
const saveManifest = () => {
  const sorted = Object.fromEntries(Object.entries(manifest).sort(([a], [b]) => a.localeCompare(b)));
  writeFileSync(MANIFEST, JSON.stringify(sorted) + "\n");
  dirty = 0;
};

// ---------- Optional S3/R2 upload ----------
let s3 = null;
if (UPLOAD) {
  for (const k of ["S3_ENDPOINT", "S3_BUCKET", "S3_ACCESS_KEY_ID", "S3_SECRET_ACCESS_KEY"]) {
    if (!process.env[k]) { console.error(`--upload needs ${k}`); process.exit(1); }
  }
  const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
  const client = new S3Client({
    region: "auto",
    endpoint: process.env.S3_ENDPOINT,
    credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY },
  });
  const prefix = process.env.S3_PREFIX ?? "p/";
  s3 = (name, body) => client.send(new PutObjectCommand({
    Bucket: process.env.S3_BUCKET, Key: prefix + name, Body: body,
    ContentType: "image/webp", CacheControl: "public, max-age=31536000, immutable",
  }));
}

// ---------- Work list ----------
const cards = JSON.parse(gunzipSync(readFileSync(CATALOG)).toString("utf8"));
const urls = new Map();
for (const c of cards) {
  const u = c.product?.image_url;
  if (!u) continue;
  const id = new URL(u).pathname.split("/").filter(Boolean).pop();
  if (id && /^[a-z0-9]+$/i.test(id)) urls.set(id, u);
}
const todo = [...urls].filter(([id]) => {
  const m = manifest[id];
  if (!m) return true;
  if (UPLOAD && !m[3]) return true; // converted earlier but never uploaded
  return false;
}).slice(0, LIMIT);

mkdirSync(OUT, { recursive: true });
console.log(`${urls.size} unique images · ${Object.keys(manifest).length} in manifest · ${todo.length} to process → ${path.relative(ROOT, OUT)}${UPLOAD ? " + bucket" : ""}`);

async function fetchImage(url) {
  const src = SOURCE ? SOURCE.replace(/\/$/, "") + new URL(url).pathname : url;
  for (let attempt = 1; ; attempt++) {
    try {
      const res = await fetch(src, { headers: { "user-agent": "PatchbayImageMirror/1.0 (+https://pluginhood.com)" }, signal: AbortSignal.timeout(30000) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return Buffer.from(await res.arrayBuffer());
    } catch (e) {
      if (attempt >= 3 || /HTTP 4\d\d/.test(e.message)) throw e;
      await new Promise((r) => setTimeout(r, 1000 * 2 ** attempt));
    }
  }
}

async function processOne(id, url) {
  const big = path.join(OUT, `${id}.webp`), card = path.join(OUT, `${id}-${CARD_W}.webp`);
  let bigBuf, cardBuf, info;
  if (manifest[id] && existsSync(big) && existsSync(card)) {
    // Converted on an earlier run; only the upload is missing.
    [bigBuf, cardBuf] = await Promise.all([readFile(big), readFile(card)]);
    info = { width: manifest[id][0], height: manifest[id][1], size: manifest[id][2] };
  } else {
    const input = await fetchImage(url);
    const base = sharp(input, { failOn: "none" }).rotate();
    const out = await base.clone().resize({ width: MAX_W, withoutEnlargement: true }).webp({ quality: QUALITY }).toBuffer({ resolveWithObject: true });
    bigBuf = out.data; info = out.info;
    cardBuf = await base.clone().resize({ width: CARD_W, withoutEnlargement: true }).webp({ quality: QUALITY }).toBuffer();
    writeFileSync(big, bigBuf);
    writeFileSync(card, cardBuf);
  }
  let uploaded = manifest[id]?.[3] ?? 0;
  if (s3) {
    await s3(`${id}.webp`, bigBuf);
    await s3(`${id}-${CARD_W}.webp`, cardBuf);
    uploaded = 1;
  }
  manifest[id] = [info.width, info.height, info.size, uploaded];
  if (++dirty >= 50) saveManifest();
}

let done = 0, failed = 0;
const failures = [];
const queue = [...todo];
const t0 = Date.now();
await Promise.all(Array.from({ length: Math.max(1, CONCURRENCY) }, async () => {
  for (let job; (job = queue.shift()); ) {
    try { await processOne(...job); done++; }
    catch (e) { failed++; failures.push(`${job[0]} ${job[1]}: ${e.message}`); }
    const n = done + failed;
    if (n % 100 === 0 || n === todo.length) console.log(`  ${n}/${todo.length} · ${failed} failed · ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  }
}));
saveManifest();

const total = Object.values(manifest).reduce((a, m) => a + m[2], 0);
console.log(`done: ${done} converted, ${failed} failed · manifest ${Object.keys(manifest).length} images, ${(total / 1e6).toFixed(1)} MB at ${MAX_W}px (+ ${CARD_W}px copies)`);
if (failures.length) { console.log("failures:\n  " + failures.slice(0, 20).join("\n  ")); process.exitCode = 1; }
