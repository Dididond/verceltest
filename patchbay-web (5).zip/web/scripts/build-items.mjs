#!/usr/bin/env node
// prebuild: writes data/items.cache.json so runtime routes (/browse, search,
// the index) start without parsing the full catalog. Runs before `npm run build`.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";
import { buildItems } from "./items.mjs";

const data = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "data");
const cards = JSON.parse(gunzipSync(readFileSync(path.join(data, "catalog_seo.json.gz"))).toString("utf8"));
const mf = path.join(data, "images.json");
let manifest = existsSync(mf) ? JSON.parse(readFileSync(mf, "utf8")) : {};
// Same rule as src/lib/data/images.ts: with local images, keep only files that exist.
const base = (process.env.NEXT_PUBLIC_IMAGE_BASE || "/product-images").replace(/\/$/, "");
if (base.startsWith("/")) {
  const dir = path.join(data, "..", "public", base);
  manifest = Object.fromEntries(Object.entries(manifest).filter(([id]) => existsSync(path.join(dir, `${id}.webp`))));
} else {
  manifest = Object.fromEntries(Object.entries(manifest).filter(([, m]) => m[3] === 1));
}
const out = buildItems(cards, manifest);
writeFileSync(path.join(data, "items.cache.json"), JSON.stringify(out));
console.log(`items cache: ${out.items.length} listable + ${out.extra.length} noindex items`);
