import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Docker builds set NEXT_OUTPUT=standalone for a self-contained server bundle;
  // local `npm start` keeps the default output.
  output: process.env.NEXT_OUTPUT === "standalone" ? "standalone" : undefined,
  // The catalog is read with fs at runtime (/browse, /api/search, the index), so make
  // sure it ships with the server bundle on standalone/serverless hosts.
  outputFileTracingIncludes: { "/*": ["./data/**/*"] },
  // Product images are pre-converted WebP copies (scripts/mirror-images.mjs)
  // served as plain <img> from IMAGE_BASE; nothing is fetched from the store's CDN.
  async headers() {
    return [
      // Mirrored images are content-addressed by the store's id, so they never change in place.
      { source: "/product-images/:file*", headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }] },
      // Keep machine endpoints out of search results even if linked externally.
      { source: "/catalog-index.json", headers: [{ key: "X-Robots-Tag", value: "noindex" }] },
      { source: "/api/:path*", headers: [{ key: "X-Robots-Tag", value: "noindex" }] },
    ];
  },
};

export default nextConfig;
