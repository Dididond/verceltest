# Patchbay web

Next.js 16 (App Router, TypeScript) implementation of the Claude Design handoff in `../project`:
Home (Spectrum hero, Signal orange accent), Catalog (`/browse`) and Product (`/product/[id]`).

```bash
npm install
npm run dev     # http://localhost:3000
npm run build && npm start
```

## Data

The real catalog lives in `data/catalog_seo.json.gz` (6,874 product cards, gzipped). It is only read on the server, in
`src/lib/data/catalog.ts`, which decompresses it once per process with `node:zlib` and serves typed getters
(`getCardByPath`, `getAllSlugs`, `getByCategory`, `getByDeveloper`, `getByRequires`, facets, stats). To update the
catalog, replace the `.gz` file and rebuild.

Client components never import the catalog. Only `/browse` downloads the slim index (`/catalog-index.json`, a compact
row format from `src/lib/indexCodec.ts`, ~860 KB raw / ~185 KB gzipped). The Home hero search calls `/api/search`.

## Product images (mirrored, never hotlinked)

`scripts/mirror-images.mjs` downloads every `product.image_url` once, converts it with sharp to WebP (q80) in two sizes:
`<id>.webp` (max 1200px wide, hero + og:image) and `<id>-480.webp` (cards). It records the real width/height in
`data/images.json`, which the build reads to set `width`/`height` on every `<img>`. Re-running only processes images
missing from the manifest. Products without a mirrored copy show a monogram placeholder.

```bash
# Option A: serve from public/ (simplest; ~0.5–1 GB of files next to the app)
npm run images:mirror                # -> public/product-images, NEXT_PUBLIC_IMAGE_BASE defaults to /product-images
npm run build

# Option B: Cloudflare R2 (or any S3-compatible bucket) behind a CDN domain
S3_ENDPOINT=https://<account>.r2.cloudflarestorage.com S3_BUCKET=patchbay-images \
S3_ACCESS_KEY_ID=... S3_SECRET_ACCESS_KEY=... npm run images:mirror -- --upload
NEXT_PUBLIC_IMAGE_BASE=https://img.pluginhood.com/p npm run build
```

Commit `data/images.json` after a run so builds know which images exist; the image files themselves are not in git.

## Routes (all statically generated except `/browse`)

| Route | Source |
|---|---|
| `/plugins/[slug]`, `/presets/[slug]` | one page per card; metadata from `card.meta`, JSON-LD from `card.json_ld` |
| `/plugins`, `/presets` (+ `/page/[n]`) | all indexable plugins / presets |
| `/plugins/category/[cat]`, `/presets/category/[cat]` (+ `/page/[n]`) | `card.category.path` |
| `/presets/for/[synth]` (+ `/page/[n]`) | presets by `product.requires` |
| `/developers`, `/developers/[dev]` (+ `/page/[n]`) | `card.developer.path` |
| `/browse` | filterable catalog; first page server-rendered, filtered URLs are `noindex` |
| `/sitemap.xml`, `/robots.txt` | indexable cards + listing pages |

Canonical URLs use `NEXT_PUBLIC_SITE_URL` (default `https://pluginhood.com`).

## Deploy

### Vercel (no server)

Import the repo in Vercel (or run `npx vercel` in `web/`) with **Root Directory = `web`**; the framework preset and
build command are detected. `npm run build` first writes `data/items.cache.json` (prebuild), which is traced into
the functions together with the gzipped catalog, so `/browse` and `/api/search` start in well under a second.

Environment variables (Project → Settings → Environment Variables), then redeploy:

| Variable | Staging / audits | Production |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | `https://test.pluginhood.com` (or the `*.vercel.app` URL) | `https://pluginhood.com` |
| `SITE_ENV` | `staging` (robots.txt blocks search engines, allows audit crawlers) | `production` |
| `NEXT_PUBLIC_IMAGE_BASE` | optional, e.g. `https://img.pluginhood.com/product-images` | same |

A custom domain is a CNAME to `cname.vercel-dns.com` (Project → Settings → Domains). Images: Vercel builds from git,
where `public/product-images/` is not committed, so either upload them once to R2
(`npm run images:mirror -- --upload`, see above) and set `NEXT_PUBLIC_IMAGE_BASE`, or leave it unset and products
show the branded placeholder. Image entries are used only when the file is actually reachable, so a missing upload
(present in `public/`, or marked uploaded in `data/images.json`) never produces broken `<img>` or image-sitemap URLs. The Hobby plan is for non-commercial use; with affiliate links
use Pro for production.

### Docker on a VPS

`deploy/` runs the app behind Caddy (automatic HTTPS) with Docker Compose on any Linux server with 2 GB RAM
(the server holds the catalog in memory, ~600 MB).

```bash
# on the server, in web/: download product images once (they're baked into the build)
npm ci && npm run images:mirror
cd deploy
DOMAIN=test.pluginhood.com docker compose up -d --build                       # staging
DOMAIN=pluginhood.com SITE_ENV=production docker compose up -d --build         # production
```

Point the domain's DNS A record at the server first; Caddy then issues the certificate on the first request.
`SITE_ENV=staging` (the compose default) blocks search engines in robots.txt but leaves SEO audit crawlers allowed,
and every canonical, sitemap and JSON-LD URL uses `https://$DOMAIN`, so audits of the test copy are self-consistent.
If Docker Hub rate-limits the base image, pass `--build-arg NODE_IMAGE=<mirror>/node:22-bookworm-slim`.

## SEO

What the build emits:

- Every indexable URL is static HTML with a unique title, description, self-referencing canonical, `og:*`/`twitter:*`
  (with `og:locale`), one `<h1>` and a `<main>` landmark. Product pages use `card.meta` and `card.json_ld` as-is.
- JSON-LD: Product, BreadcrumbList and FAQPage on products; Organization and WebSite on Home; BreadcrumbList and
  CollectionPage/ItemList on listings.
- `noindex,follow`: upgrade/crossgrade variants, flagged cards, filtered/sorted `/browse` URLs, and listings with fewer
  than 3 products (`MIN_INDEXABLE_ITEMS` in `src/lib/listings.ts`), which would otherwise be near-duplicates of a product.
- `/sitemap.xml` is a sitemap index of `/sitemaps/{pages,plugins,presets}.xml`, listing only indexable URLs, with
  `<image:image>` entries for mirrored product images.
- Icons, web manifest and a generated 1200×630 share image (`src/app/opengraph-image.tsx`).

Launch checklist:

1. Set `NEXT_PUBLIC_SITE_URL` to the final origin (it drives every canonical and sitemap URL) and redirect the other
   variants (http, www/non-www, trailing slash) to it with a 301 at the host/CDN.
2. Mirror images (`npm run images:mirror`) before building, so product pages and the image sitemap have pictures.
3. Verify ownership: set `GOOGLE_SITE_VERIFICATION`, `BING_SITE_VERIFICATION` (and optionally `YANDEX_VERIFICATION`),
   rebuild, then submit `https://<site>/sitemap.xml` in Google Search Console and Bing Webmaster Tools.
4. IndexNow (Bing, Yandex, Seznam, Naver): set `INDEXNOW_KEY` (32 hex chars) on the server, then after each deploy run
   `INDEXNOW_KEY=... npm run seo:indexnow` (all sitemap URLs) or pass specific paths.

## Notes

- Listings include only `indexable` cards; noindex upgrade/crossgrade and flagged cards still get product pages.
- No prices anywhere: the catalog's price fields are never rendered, indexed or sent to the browser, and the Offer
  (with price) is stripped from Product JSON-LD. Store links say "View on Plugin Boutique".
- Theme tokens live in `src/app/globals.css`; `BRAND` in `src/lib/site.ts` renames the site.
- The release-alert form is UI only; there is no email backend yet.
