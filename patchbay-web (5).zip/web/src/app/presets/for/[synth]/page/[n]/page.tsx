import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing/ListingView";
import { extraPages, getRequiresList, isThin, requiresListing } from "@/lib/listings";
import { listingMetadata } from "@/lib/seo";

export const dynamicParams = false;

type P = { params: Promise<{ synth: string; n: string }> };
const get = (p: { synth: string; n: string }) => requiresListing(p.synth);

export function generateStaticParams() {
  return getRequiresList().flatMap((r) => {
    const synth = r.path.split("/").pop()!;
    return extraPages(requiresListing(synth)!).map((n) => ({ synth, n }));
  });
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return listingMetadata({ title: l.title, description: l.description, path: l.path, noindex: isThin(l), page: +p.n });
}

export default async function Page({ params }: P) {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return <ListingView listing={l} page={+p.n} />;
}
