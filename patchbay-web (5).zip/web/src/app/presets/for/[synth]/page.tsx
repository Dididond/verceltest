import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing/ListingView";
import { getRequiresList, isThin, requiresListing } from "@/lib/listings";
import { listingMetadata } from "@/lib/seo";

export const dynamicParams = false;

type P = { params: Promise<{ synth: string }> };
const get = (p: { synth: string }) => requiresListing(p.synth);

export function generateStaticParams() {
  return getRequiresList().map((r) => ({ synth: r.path.split("/").pop()! }));
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return listingMetadata({ title: l.title, description: l.description, path: l.path, noindex: isThin(l), page: 1 });
}

export default async function Page({ params }: P) {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return <ListingView listing={l} page={1} />;
}
