import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing/ListingView";
import { categoryListing, getCategories, isThin } from "@/lib/listings";
import { listingMetadata } from "@/lib/seo";

export const dynamicParams = false;

type P = { params: Promise<{ cat: string }> };
const get = (p: { cat: string }) => categoryListing("preset", p.cat);

export function generateStaticParams() {
  return getCategories().filter((c) => c.type === "preset").map((c) => ({ cat: c.path.split("/").pop()! }));
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return listingMetadata({ title: l.title, description: l.description, path: l.path, noindex: isThin(l), page: 1 });
}

export default async function Page({ params }: P) {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return <ListingView listing={l} page={1} />;
}
