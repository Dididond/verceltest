import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductPage } from "@/components/product/ProductPage";
import { getAllSlugs, getCardByPath } from "@/lib/data/catalog";
import { cardMetadata } from "@/lib/seo";

export const dynamicParams = false;

export function generateStaticParams() {
  return getAllSlugs("preset").map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const card = getCardByPath("/presets/" + (await params).slug);
  if (!card) notFound();
  return cardMetadata(card);
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  return <ProductPage type="preset" slug={(await params).slug} />;
}
