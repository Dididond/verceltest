import { gzipSync } from "node:zlib";
import { getItems } from "@/lib/data/catalog";
import { packIndex } from "@/lib/indexCodec";

// Slim listing index for client-side filtering on /browse only. Built once per
// server process and served pre-gzipped (Next doesn't compress route handlers).
let body: { raw: Buffer; gz: Buffer } | null = null;
const build = () => {
  const raw = Buffer.from(JSON.stringify(packIndex(getItems())));
  return { raw, gz: gzipSync(raw, { level: 9 }) };
};

export function GET(req: Request) {
  body ??= build();
  const gzip = /\bgzip\b/.test(req.headers.get("accept-encoding") ?? "");
  const data = gzip ? body.gz : body.raw;
  return new Response(new Uint8Array(data), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "public, max-age=3600, stale-while-revalidate=86400",
      vary: "Accept-Encoding",
      ...(gzip ? { "content-encoding": "gzip" } : {}),
    },
  });
}
