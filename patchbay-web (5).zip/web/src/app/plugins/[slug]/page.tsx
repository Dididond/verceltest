import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductPage } from "@/components/product/ProductPage";
import { getAllSlugs, getCardByPath } from "@/lib/data/catalog";
import { cardMetadata } from "@/lib/seo";

export const dynamicParams = false;

export function generateStaticParams() {
  return getAllSlugs("plugin").map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const card = getCardByPath("/plugins/" + (await params).slug);
  if (!card) notFound();
  return cardMetadata(card);
}

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  return <ProductPage type="plugin" slug={(await params).slug} />;
}
