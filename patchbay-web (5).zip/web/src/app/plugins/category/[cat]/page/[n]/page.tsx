import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing/ListingView";
import { categoryListing, extraPages, getCategories, isThin } from "@/lib/listings";
import { listingMetadata } from "@/lib/seo";

export const dynamicParams = false;

type P = { params: Promise<{ cat: string; n: string }> };
const get = (p: { cat: string; n: string }) => categoryListing("plugin", p.cat);

export function generateStaticParams() {
  return getCategories().filter((c) => c.type === "plugin").flatMap((c) => {
    const cat = c.path.split("/").pop()!;
    return extraPages(categoryListing("plugin", cat)!).map((n) => ({ cat, n }));
  });
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return listingMetadata({ title: l.title, description: l.description, path: l.path, noindex: isThin(l), page: +p.n });
}

export default async function Page({ params }: P) {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return <ListingView listing={l} page={+p.n} />;
}
