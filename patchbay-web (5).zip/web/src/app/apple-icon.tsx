import { ImageResponse } from "next/og";

export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#121110" }}>
        <div style={{ width: 104, height: 104, borderRadius: 52, border: "14px solid #f4f1ec", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: 34, height: 34, borderRadius: 17, background: "#ff7a1a" }} />
        </div>
      </div>
    ),
    size,
  );
}
