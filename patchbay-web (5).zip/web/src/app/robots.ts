import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";

// Search engines kept off a staging copy; SEO audit crawlers (Screaming Frog,
// Ahrefs, Semrush, Lighthouse…) use their own user agents and stay allowed.
const SEARCH_ENGINES = ["Googlebot", "Googlebot-Image", "Google-Extended", "Bingbot", "AdIdxBot", "YandexBot", "YandexImages", "DuckDuckBot", "Applebot", "Baiduspider", "Slurp"];

export default function robots(): MetadataRoute.Robots {
  const staging = process.env.SITE_ENV === "staging";
  return {
    rules: [
      ...(staging ? [{ userAgent: SEARCH_ENGINES, disallow: "/" }] : []),
      { userAgent: "*", allow: "/", disallow: ["/api/"] },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
