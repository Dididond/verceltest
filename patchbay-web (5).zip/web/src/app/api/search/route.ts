import { quickSearch } from "@/lib/search";

export function GET(req: Request) {
  const q = (new URL(req.url).searchParams.get("q") ?? "").slice(0, 120);
  return Response.json(quickSearch(q), { headers: { "cache-control": "public, max-age=300, stale-while-revalidate=3600" } });
}
