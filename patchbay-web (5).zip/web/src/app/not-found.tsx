import Link from "next/link";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";

export default function NotFound() {
  return (
    <div className="page">
      <SiteHeader />
      <section className="wrap" style={{ padding: "clamp(64px,10vw,140px) var(--pad)", display: "flex", flexDirection: "column", gap: 20 }}>
        <div className="eyebrow"><b>404</b><i />Signal lost</div>
        <h1 className="h2">Nothing on this channel.</h1>
        <p style={{ margin: 0, maxWidth: 480, font: "400 17px/1.6 var(--f-sans)", color: "var(--ink2)" }}>The page may have moved. Try browsing the catalog instead.</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Link href="/browse" className="pill-link">Browse everything <span>→</span></Link>
          <Link href="/" className="pill-link">Home <span>→</span></Link>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
