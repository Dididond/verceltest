import type { Metadata, Viewport } from "next";
import { Archivo, Geist, Geist_Mono } from "next/font/google";
import { MotionLayer } from "@/components/shared/MotionLayer";
import { ViewTransitions } from "@/components/shared/ViewTransitions";
import { BRAND, SITE_URL } from "@/lib/site";
import { THEME_BOOT } from "@/lib/theme";
import "./globals.css";

const archivo = Archivo({ subsets: ["latin"], axes: ["wdth"], variable: "--font-archivo", display: "swap" });
const geist = Geist({ subsets: ["latin"], variable: "--font-geist", display: "swap" });
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: `${BRAND} — Find the sound you're missing`, template: `%s — ${BRAND}` },
  description: "Discover, compare and buy audio plugins and synth presets: formats, compatibility, host requirements and ratings.",
  applicationName: BRAND,
  // Search Console / Bing Webmaster / Yandex ownership tags, set per deployment.
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION,
    yandex: process.env.YANDEX_VERIFICATION,
    other: process.env.BING_SITE_VERIFICATION ? { "msvalidate.01": process.env.BING_SITE_VERIFICATION } : undefined,
  },
  formatDetection: { telephone: false, email: false, address: false },
};

export const viewport: Viewport = {
  themeColor: "#121110",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" className={`${archivo.variable} ${geist.variable} ${geistMono.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOT }} />
      </head>
      <body>
        <MotionLayer />
        <ViewTransitions />
        {children}
      </body>
    </html>
  );
}
