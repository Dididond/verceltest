import { notFound } from "next/navigation";
import { SITEMAPS, type SitemapName, entries, urlset, xml } from "@/lib/sitemaps";

export const dynamic = "force-static";
export const dynamicParams = false;

export function generateStaticParams() {
  return SITEMAPS.map((n) => ({ name: `${n}.xml` }));
}

export async function GET(_req: Request, { params }: { params: Promise<{ name: string }> }) {
  const name = (await params).name.replace(/\.xml$/, "") as SitemapName;
  if (!SITEMAPS.includes(name)) notFound();
  return xml(urlset(entries(name)));
}
