import type { Metadata } from "next";
import Link from "next/link";
import s from "@/components/listing/listing.module.css";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";
import { getDevelopers } from "@/lib/data/catalog";
import { listingMetadata } from "@/lib/seo";

export function generateMetadata(): Metadata {
  return listingMetadata({
    title: "Plugin & Preset Developers A–Z",
    description: `All ${getDevelopers().length} plugin and preset developers in the catalog, with product counts and ratings.`,
    path: "/developers",
  });
}

export default function DevelopersPage() {
  const devs = [...getDevelopers()].sort((a, b) => a.name.localeCompare(b.name));
  const groups = new Map<string, typeof devs>();
  for (const d of devs) {
    const k = /[a-z]/i.test(d.name[0]) ? d.name[0].toUpperCase() : "#";
    groups.set(k, [...(groups.get(k) ?? []), d]);
  }
  return (
    <div className="page">
      <SiteHeader active="developers" />
<main>
      <section className={`wrap ${s.head}`}>
        <nav aria-label="Breadcrumb">
          <ol className={s.crumbs}><li><Link href="/">Home</Link></li><li><span aria-current="page">Developers</span></li></ol>
        </nav>
        <div data-reveal="" className={s.titleRow}>
          <h1 className={s.h1}>Developers<span className={s.count}>{devs.length} studios</span></h1>
          <p className={s.intro}>Every developer and sound designer in the catalog, A to Z. Each page lists all of their plugins and preset packs with formats, ratings and host requirements.</p>
        </div>
      </section>
      <section className="wrap" aria-label="Developers A to Z">
        {[...groups].map(([letter, list]) => (
          <div key={letter} className={s.more} style={{ paddingTop: 36 }}>
            <h2 className={s.moreH}>{letter}</h2>
            <ul className={s.links}>
              {list.map((d) => <li key={d.path}><Link href={d.path}>{d.name}<span>{d.count}</span></Link></li>)}
            </ul>
          </div>
        ))}
      </section>
</main>
      <SiteFooter style={{ marginTop: "clamp(80px,10vw,140px)" }} />
    </div>
  );
}
