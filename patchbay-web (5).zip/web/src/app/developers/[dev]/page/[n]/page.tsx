import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing/ListingView";
import { developerListing, extraPages, getDevelopers, isThin } from "@/lib/listings";
import { listingMetadata } from "@/lib/seo";

export const dynamicParams = false;

type P = { params: Promise<{ dev: string; n: string }> };
const get = (p: { dev: string; n: string }) => developerListing(p.dev);

export function generateStaticParams() {
  return getDevelopers().flatMap((d) => {
    const dev = d.path.split("/").pop()!;
    return extraPages(developerListing(dev)!).map((n) => ({ dev, n }));
  });
}

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return listingMetadata({ title: l.title, description: l.description, path: l.path, noindex: isThin(l), page: +p.n });
}

export default async function Page({ params }: P) {
  const p = await params;
  const l = get(p);
  if (!l) notFound();
  return <ListingView listing={l} page={+p.n} />;
}
