// IndexNow ownership key (Bing, Yandex, Seznam, Naver). Set INDEXNOW_KEY to a
// random 32-char hex string; scripts/indexnow.mjs submits URLs with it.
export const dynamic = "force-dynamic";

export function GET() {
  const key = process.env.INDEXNOW_KEY;
  if (!key) return new Response("Not found", { status: 404 });
  return new Response(key, { headers: { "content-type": "text/plain; charset=utf-8" } });
}
