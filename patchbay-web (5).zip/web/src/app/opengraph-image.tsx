import { ImageResponse } from "next/og";
import { getStats } from "@/lib/data/catalog";
import { BRAND } from "@/lib/site";

// Default share image for every page that doesn't have product art.
export const alt = `${BRAND} — find the sound you're missing`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  const s = getStats();
  const bars = Array.from({ length: 48 }, (_, i) => 30 + Math.round(170 * Math.abs(Math.sin(i * 0.37) * Math.cos(i * 0.11))));
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", background: "#121110", color: "#f4f1ec", padding: 64, position: "relative" }}>
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 220, display: "flex", alignItems: "flex-end", gap: 6, padding: "0 24px", opacity: 0.55 }}>
          {bars.map((h, i) => <div key={i} style={{ flex: 1, height: h, background: "#ff7a1a", borderRadius: 2 }} />)}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 18, fontSize: 40, fontWeight: 800 }}>
          <div style={{ width: 44, height: 44, borderRadius: 22, border: "6px solid #f4f1ec", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: 14, height: 14, borderRadius: 7, background: "#ff7a1a" }} />
          </div>
          {BRAND}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 18, marginBottom: 150 }}>
          <div style={{ fontSize: 92, fontWeight: 800, letterSpacing: -4, lineHeight: 0.95 }}>Find the sound you&apos;re missing.</div>
          <div style={{ fontSize: 30, color: "#c9c3ba" }}>
            {`${s.plugins.toLocaleString("en-US")} plugins · ${s.presets.toLocaleString("en-US")} preset packs · ${s.developers} developers`}
          </div>
        </div>
      </div>
    ),
    size,
  );
}
