import type { Metadata } from "next";
import Link from "next/link";
import { Alerts } from "@/components/home/Alerts";
import { CategoryRack, type RackCategory } from "@/components/home/CategoryRack";
import { Favourites } from "@/components/home/Favourites";
import { HomeTop } from "@/components/home/HomeTop";
import { Spotlight, type SpotlightDev } from "@/components/home/Spotlight";
import { Trending } from "@/components/home/Trending";
import s from "@/components/home/home.module.css";
import { getCategory, getDevelopers, getItems, getRequiresList, getStats } from "@/lib/data/catalog";
import type { Item } from "@/lib/data/types";
import type { Motif } from "@/lib/dsp";
import { pluralize } from "@/lib/format";
import { absUrl, jsonLd, organizationLd, websiteLd } from "@/lib/seo";
import { BRAND, STORE_NAME } from "@/lib/site";

const HOME_DESCRIPTION = "Discover, compare and buy audio plugins and synth presets. Formats, OS compatibility, host requirements and ratings for thousands of products.";

export const metadata: Metadata = {
  title: { absolute: `${BRAND} — Find the sound you're missing` },
  description: HOME_DESCRIPTION,
  alternates: { canonical: absUrl("/") },
  openGraph: {
    title: `${BRAND} — Find the sound you're missing`, description: HOME_DESCRIPTION, url: absUrl("/"), siteName: BRAND, type: "website", locale: "en_US",
    images: [{ url: "/opengraph-image", width: 1200, height: 630, alt: `${BRAND} — audio plugins and presets compared` }],
  },
  twitter: { card: "summary_large_image", title: `${BRAND} — Find the sound you're missing`, description: HOME_DESCRIPTION, images: ["/opengraph-image"] },
};

const RACK: [string, Motif][] = [
  ["/plugins/category/synths", "saw"],
  ["/plugins/category/kontakt-instruments", "grain"],
  ["/plugins/category/reverbs", "decay"],
  ["/plugins/category/delays", "ping"],
  ["/plugins/category/compressors", "knee"],
  ["/plugins/category/eq", "eq"],
  ["/plugins/category/saturation", "clip"],
  ["/plugins/category/limiters", "limit"],
  ["/plugins/category/utilities", "util"],
  ["/presets/category/synth-presets", "dots"],
];

const ratedBy = (i: Item) => (i.rt != null && i.rc >= 50 ? i.rt : 0);

function spotlight(items: Item[]): SpotlightDev {
  // The developer whose catalogue has collected the most store ratings.
  const dev = getDevelopers()
    .filter((d) => d.count >= 5)
    .map((d) => ({ d, mine: items.filter((i) => i.dp === d.path) }))
    .map((x) => ({ ...x, ratings: x.mine.reduce((a, i) => a + i.rc, 0) }))
    .sort((a, b) => b.ratings - a.ratings)[0];
  const rated = dev.mine.filter((i) => i.rt != null && i.rc > 0);
  return {
    name: dev.d.name,
    path: dev.d.path,
    products: dev.mine.length,
    avgRating: rated.reduce((a, i) => a + i.rt! * i.rc, 0) / Math.max(1, dev.ratings),
    ratings: dev.ratings,
    categories: [...new Set(dev.mine.map((i) => i.c))],
    top: dev.mine.slice(0, 3).map((i) => ({ name: i.n, path: i.p, meta: [i.c, ...i.f.slice(0, 3)].join(" · "), right: i.rt != null && i.rc > 0 ? `★ ${i.rt.toFixed(1)}` : "→" })),
  };
}

export default function HomePage() {
  const items = getItems();
  const stats = getStats();
  const trending = items.slice(0, 10);
  const favourites = [...items].filter((i) => (i.rt ?? 0) >= 4.5 && i.rc >= 50).sort((a, b) => b.rt! - a.rt! || b.rc - a.rc).slice(0, 60);
  const topRated = [...items].sort((a, b) => ratedBy(b) - ratedBy(a) || b.rc - a.rc).slice(0, 6);
  const synths = getRequiresList().slice(0, 8);
  const rack: RackCategory[] = RACK.flatMap(([path, motif]) => {
    const c = getCategory(path);
    return c ? [{ name: c.name, path, count: c.count, motif, sub: pluralize(c.developers, "developer") }] : [];
  });
  const statRow = [["Plugins", stats.plugins], ["Preset packs", stats.presets], ["Developers", stats.developers], ["Categories", stats.categories]] as const;
  const marquee = [...stats.formats.map((f) => f.toUpperCase()), "WINDOWS", "MACOS", "LINUX", "64-BIT", "FREE TRIALS"];
  const footer = [
    { title: "Browse", links: [["All plugins", "/plugins"], ["Preset packs", "/presets"], ["Top rated", "/browse?sort=Highest+rated"], ["Filter everything", "/browse"], ["Developers", "/developers"]] },
    { title: "Categories", links: rack.slice(0, 6).map((c) => [c.name, c.path]) },
    { title: "Presets for", links: synths.slice(0, 5).map((r) => [r.name, r.path]) },
    { title: "Company", links: [["About", "#"], ["For developers", "#"], ["Affiliate disclosure", "#"], ["Contact", "#"]] },
  ];

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(organizationLd()) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(websiteLd(HOME_DESCRIPTION)) }} />
      <HomeTop stats={{ plugins: stats.plugins, presets: stats.presets, developers: stats.developers, categories: stats.categories }} />
      <main className={s.main}>
        <section className={`wrap ${s.statsSec}`} aria-label="Catalog in numbers">
          <div className={s.stats}>
            {statRow.map(([label, n]) => (
              <div key={label}>
                <span>{label}</span>
                <span data-count={n}>{n.toLocaleString("en-US")}</span>
              </div>
            ))}
          </div>
          <div className={s.marqueeMask} aria-hidden="true">
            <div className={s.marquee}>
              {[...marquee, ...marquee].map((m, i) => <span key={i}>{m}<i /></span>)}
            </div>
          </div>
        </section>

        <section id="browse" className={`wrap ${s.section}`} aria-labelledby="browse-h">
          <div data-reveal="" className="section-head" style={{ marginBottom: 40 }}>
            <div>
              <div className="eyebrow"><b>01</b><i />Browse by category</div>
              <h2 id="browse-h" className="h2" style={{ textWrap: "balance" }}>Start with what it does.</h2>
            </div>
            <Link href="/plugins" data-magnetic="" className="pill-link">All {stats.categories} categories <span>→</span></Link>
          </div>
          <CategoryRack cats={rack} />
        </section>

        <Trending products={trending} />
        <Favourites products={favourites} />

        <section className={`wrap ${s.section}`} aria-labelledby="top-h">
          <div data-reveal="" className="section-head" style={{ marginBottom: 28 }}>
            <div>
              <div className="eyebrow"><b>04</b><i />50+ ratings</div>
              <h2 id="top-h" className="h2">Highest rated</h2>
            </div>
            <Link href="/browse?sort=Highest+rated" data-magnetic="" className="pill-link">All by rating <span>→</span></Link>
          </div>
          <div className={s.releases}>
            {topRated.map((p) => (
              <Link key={p.p} href={p.p} data-reveal="" data-cursor="View" className={s.release}>
                <span className={s.relDate}>★ {p.rt!.toFixed(1)}</span>
                <span className={s.relName}><span>{p.n}</span><span>{p.d}</span></span>
                <span className={s.relCat}>{p.c}</span>
                <span className="badges">{[p.r?.toUpperCase(), ...p.f].filter(Boolean).slice(0, 4).map((f) => <span key={f} className="badge">{f}</span>)}</span>
                <span className={s.relPrice}>{p.rc.toLocaleString("en-US")} ratings</span>
                <span className={s.relArrow}>→</span>
              </Link>
            ))}
          </div>
        </section>

        <section id="presets" className={`wrap ${s.section}`} aria-labelledby="presets-h">
          <div data-reveal="" className="section-head" style={{ marginBottom: 36 }}>
            <div>
              <div className="eyebrow"><b>05</b><i />{stats.presets.toLocaleString("en-US")} packs</div>
              <h2 id="presets-h" className="h2">Presets by synth</h2>
            </div>
            <p className={s.presetsLede}>Already own the synth? Every pack lists the exact host it needs. {stats.synths} synths and samplers covered.</p>
          </div>
          <div data-rack="" className={s.synths}>
            {synths.map((r) => (
              <Link key={r.path} href={r.path} data-tile="" data-cursor="Browse" className={s.synth}>
                <div><span>{r.count} PACKS</span><span>{pluralize(r.developers, "DESIGNER")}</span></div>
                <span>{r.name}</span>
              </Link>
            ))}
          </div>
        </section>

        <Spotlight dev={spotlight(items)} />
        <Alerts />

        <footer className={s.footer}>
          <div className={`wrap ${s.footCols}`}>
            {footer.map((c) => (
              <div key={c.title}>
                <span>{c.title}</span>
                {c.links.map(([label, href]) => <Link key={label} href={href}>{label}</Link>)}
              </div>
            ))}
          </div>
          <div className="wrap">
            <div data-reveal="" className={s.wordmark}>{BRAND}</div>
          </div>
          <div className={`wrap ${s.legal}`}>
            <span>© 2026 {BRAND}. Ratings from {STORE_NAME}.</span>
            <span>We may earn a commission from store links.</span>
          </div>
        </footer>
      </main>
    </>
  );
}
