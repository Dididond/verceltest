import type { Metadata } from "next";
import { CatalogView } from "@/components/catalog/CatalogView";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";
import { getCategories, getItems, getRequiresList } from "@/lib/data/catalog";
import { PAGE_SIZE, filtersFromParams, results } from "@/lib/filters";
import { listingMetadata } from "@/lib/seo";

type SP = Promise<Record<string, string | string[] | undefined>>;

const BASE = {
  title: "Browse All Plugins & Presets",
  description: "Filter every plugin and preset pack by type, category, format, operating system and host synth. Sorted by how many producers have rated them.",
  path: "/browse",
};

// Filtered and sorted variants are noindex and canonicalise to the clean /browse.
export async function generateMetadata({ searchParams }: { searchParams: SP }): Promise<Metadata> {
  const filtered = Object.keys(await searchParams).length > 0;
  return listingMetadata({ ...BASE, noindex: filtered });
}

export default async function BrowsePage({ searchParams }: { searchParams: SP }) {
  const { filters, sort } = filtersFromParams(await searchParams);
  const res = results(getItems(), filters, sort);
  const categories = getCategories().map((c) => ({ name: c.name, path: c.path, type: c.type!, count: c.count }));
  const synths = getRequiresList().map((r) => ({ name: r.name, count: r.count }));
  return (
    <div className="page">
      <SiteHeader active="browse" />
<main>
      <CatalogView
        key={JSON.stringify(filters) + sort}
        initial={filters}
        initialSort={sort}
        initialItems={res.slice(0, PAGE_SIZE)}
        initialTotal={res.length}
        categories={categories}
        synths={synths}
      />
</main>
      <SiteFooter style={{ marginTop: "clamp(80px,10vw,140px)" }} />
    </div>
  );
}
