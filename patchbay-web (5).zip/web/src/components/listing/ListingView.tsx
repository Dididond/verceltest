import Link from "next/link";
import { notFound } from "next/navigation";
import { CardGrid } from "@/components/shared/CardGrid";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";
import { PAGE_SIZE } from "@/lib/filters";
import { type Listing, pageCount, pageItems } from "@/lib/listings";
import { absUrl, collectionLd, jsonLd } from "@/lib/seo";
import s from "./listing.module.css";

export const pageHref = (base: string, n: number) => (n <= 1 ? base : `${base}/page/${n}`);

/** Numbered pagination made of plain links so every page is crawlable. */
export function Pagination({ base, page, pages }: { base: string; page: number; pages: number }) {
  if (pages <= 1) return null;
  const nums = [...new Set([1, page - 2, page - 1, page, page + 1, page + 2, pages])].filter((n) => n >= 1 && n <= pages).sort((a, b) => a - b);
  return (
    <nav aria-label="Pagination" className={s.pager}>
      {page > 1 ? <Link href={pageHref(base, page - 1)} rel="prev" className={s.step}>← Previous</Link> : <span className={s.step} aria-disabled="true">← Previous</span>}
      <ol>
        {nums.map((n, i) => (
          <li key={n}>
            {i > 0 && n - nums[i - 1] > 1 && <span className={s.gap}>…</span>}
            {n === page ? <span aria-current="page" className={s.num}>{n}</span> : <Link href={pageHref(base, n)} className={s.num}>{n}</Link>}
          </li>
        ))}
      </ol>
      {page < pages ? <Link href={pageHref(base, page + 1)} rel="next" className={s.step}>Next →</Link> : <span className={s.step} aria-disabled="true">Next →</span>}
    </nav>
  );
}

export function ListingView({ listing: l, page }: { listing: Listing; page: number }) {
  const pages = pageCount(l);
  if (page < 1 || page > pages) notFound();
  const items = pageItems(l, page);
  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: l.crumbs.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: absUrl(c.path) })),
  };

  return (
    <div className="page">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(breadcrumbLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(collectionLd({ name: l.h1, description: l.description, path: page > 1 ? pageHref(l.path, page) : l.path, items, offset: (page - 1) * PAGE_SIZE })) }} />
      <SiteHeader active={l.path.startsWith("/presets") ? "presets" : l.path.startsWith("/developers") ? "developers" : "browse"} />

<main>
      <section className={`wrap ${s.head}`}>
        <nav aria-label="Breadcrumb">
          <ol className={s.crumbs}>
            {l.crumbs.map((c, i) => (
              <li key={c.path}>{i < l.crumbs.length - 1 ? <Link href={c.path}>{c.name}</Link> : <span aria-current="page">{c.name}</span>}</li>
            ))}
          </ol>
        </nav>
        <div data-reveal="" className={s.titleRow}>
          <h1 className={s.h1}>{l.h1}<span className={s.count}>{l.items.length.toLocaleString("en-US")} results{pages > 1 ? ` · page ${page} of ${pages}` : ""}</span></h1>
          <p className={s.intro}>{l.intro}</p>
        </div>
        <div className={s.tools}>
          <span className="eyebrow"><b>●</b><i />{l.eyebrow}</span>
          <Link href={`/browse?${new URLSearchParams(l.path.includes("/category/") ? { cat: l.path } : l.path.startsWith("/presets/for/") ? { type: "preset", requires: l.h1.replace(/^Presets for /, "") } : l.path === "/plugins" ? { type: "plugin" } : l.path === "/presets" ? { type: "preset" } : { q: l.h1 })}`} className="pill-link">
            Filter & sort <span>→</span>
          </Link>
        </div>
      </section>

      <section className="wrap" aria-label="Products">
        <CardGrid className={s.grid} items={items.map(({ dp: _dp, s: _s, cp: _cp, ...rest }) => rest as typeof items[number])} />
        <Pagination base={l.path} page={page} pages={pages} />
      </section>

      {l.more && l.more.links.length > 0 && (
        <section className={`wrap ${s.more}`} aria-labelledby="more-h">
          <h2 id="more-h" className={s.moreH}>{l.more.heading}</h2>
          <ul className={s.links}>
            {l.more.links.map((f) => (
              <li key={f.path}><Link href={f.path}>{f.name}<span>{f.count}</span></Link></li>
            ))}
          </ul>
        </section>
      )}

</main>
      <SiteFooter style={{ marginTop: "clamp(80px,10vw,140px)" }} />
    </div>
  );
}
