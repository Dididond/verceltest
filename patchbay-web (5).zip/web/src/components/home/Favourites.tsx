"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { ProductImage } from "@/components/shared/ProductCard";
import type { Item } from "@/lib/data/types";
import { useFlip } from "@/lib/useFlip";
import s from "./home.module.css";

const FILTERS = [["all", "All"], ["plugin", "Plugins"], ["preset", "Presets"], ["kontakt", "Kontakt"]] as const;
type Filter = (typeof FILTERS)[number][0];

const pick = (i: Item, f: Filter) => f === "all" || (f === "kontakt" ? i.r === "Kontakt" || i.f.includes("Kontakt") : i.t === f);

/** Best-rated products with a meaningful number of ratings. */
export function Favourites({ products }: { products: Item[] }) {
  const [filter, setFilter] = useState<Filter>("all");
  const grid = useRef<HTMLDivElement>(null);
  const capture = useFlip(grid, filter);
  const list = products.filter((d) => pick(d, filter)).slice(0, 8);

  return (
    <section id="favourites" className={`wrap ${s.section}`} aria-labelledby="fav-h">
      <div data-reveal="" className="section-head" style={{ marginBottom: 36 }}>
        <div>
          <div className="eyebrow"><b style={{ color: "var(--deal)" }}>03</b><i />4.5+ from 50+ ratings</div>
          <h2 id="fav-h" className="h2">Producer favourites</h2>
        </div>
        <div role="group" aria-label="Filter favourites" className={s.dealChips}>
          {FILTERS.map(([f, label]) => (
            <button key={f} type="button" aria-pressed={filter === f} onClick={() => { capture(); setFilter(f); }}>
              <span className="led deal" data-on={filter === f} />{label}
            </button>
          ))}
        </div>
      </div>
      <div ref={grid} className={s.dealGrid}>
        {list.map((d) => (
          <div key={d.p} data-flip={d.p}>
            <Link href={d.p} data-tilt="" data-cursor="View" data-vt-source="" className={s.deal}>
              <div data-glow="" />
              <div className={s.dealTop}>
                <span className={s.pctBig}>{d.rt!.toFixed(1)}</span>
                <div className={s.ends}>
                  <span><span className="dot-live deal" />RATINGS</span>
                  <span>{d.rc.toLocaleString("en-US")}</span>
                </div>
              </div>
              <div className={`${s.dealImg} stripes`} data-vt-image=""><ProductImage item={d} /></div>
              <div className={s.dealName}>
                <span>{d.d} · {d.c}</span>
                <span>{d.n}</span>
              </div>
              <div className={s.dealFoot}>
                <div className="badges">{[d.r?.toUpperCase(), ...d.f].filter(Boolean).slice(0, 3).map((f) => <span key={f} className="badge">{f}</span>)}</div>
                <span>on Plugin Boutique</span>
              </div>
            </Link>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "center", marginTop: 28 }}>
        <Link href="/browse?sort=Highest+rated" data-magnetic="" className="pill-link">Everything by rating <span>→</span></Link>
      </div>
    </section>
  );
}
