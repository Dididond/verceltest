"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { SiteHeader } from "@/components/shared/SiteHeader";
import type { Hit, SearchResult } from "@/lib/search";
import { type SpecState, drawSpectrum, fitCanvas, hzLabel } from "@/lib/dsp";
import { EASE } from "@/lib/site";
import { useCanvasColors } from "@/lib/theme";
import s from "./HomeTop.module.css";

const SUGGESTIONS = ["presets for Serum", "tape saturation", "Kontakt instruments", "vocal processing", "amp simulators"];
const PLACEHOLDERS = SUGGESTIONS.map((x) => `Try “${x}”`);
const LINES = [["Find", "the", "sound"], ["you’re", "missing."]];
const EMPTY: SearchResult = { groups: [], noResults: false, label: "Searching…" };

export function HomeTop({ stats }: { stats: { plugins: number; presets: number; developers: number; categories: number } }) {
  const router = useRouter();
  const colors = useCanvasColors();
  const [q, setQ] = useState("");
  const [focus, setFocus] = useState(false);
  const [sel, setSel] = useState(-1);
  const [res, setRes] = useState<SearchResult>(EMPTY);
  const input = useRef<HTMLInputElement>(null);
  const hero = useRef<HTMLElement>(null);
  const heroInner = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const readout = useRef<HTMLSpanElement>(null);
  const colorsRef = useRef(colors);
  colorsRef.current = colors;

  // Quick search runs on the server; the page never downloads the catalog index.
  useEffect(() => {
    if (!focus) return;
    const ctrl = new AbortController();
    const t = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(q)}`, { signal: ctrl.signal })
        .then((r) => r.json() as Promise<SearchResult>)
        .then(setRes, () => {});
    }, q ? 120 : 0);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [q, focus]);
  const flat = useMemo(() => res.groups.flatMap((g) => g.items), [res]);
  useEffect(() => setSel(-1), [q]);

  const focusSearch = useCallback(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
    input.current?.focus({ preventScroll: true });
  }, []);

  const pick = (h: Hit) => router.push(h.href);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (sel >= 0 && flat[sel]) return pick(flat[sel]);
    router.push(q.trim() ? `/browse?q=${encodeURIComponent(q.trim())}` : "/browse");
  };
  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      if (!flat.length) return;
      setSel((i) => (e.key === "ArrowDown" ? (i + 1) % flat.length : (i <= 0 ? flat.length : i) - 1));
    } else if (e.key === "Escape") {
      input.current?.blur();
    }
  };

  // ⌘K / Ctrl+K and rotating placeholder hints.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); focusSearch(); }
    };
    addEventListener("keydown", onKey);
    let pi = 0;
    const pt = setInterval(() => {
      if (input.current) { pi = (pi + 1) % PLACEHOLDERS.length; input.current.placeholder = PLACEHOLDERS[pi]; }
    }, 2800);
    return () => { removeEventListener("keydown", onKey); clearInterval(pt); };
  }, [focusSearch]);

  // Headline reveal.
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches || !hero.current) return;
    hero.current.querySelectorAll<HTMLElement>("[data-word]").forEach((w, i) =>
      w.animate([{ transform: "translateY(110%) rotate(4deg)" }, { transform: "none" }], { duration: 1200, delay: 120 + i * 80, easing: EASE.outExpo, fill: "backwards" }),
    );
    hero.current.querySelectorAll<HTMLElement>("[data-intro]").forEach((el) =>
      el.animate([{ opacity: 0, transform: "translateY(18px)" }, { opacity: 1, transform: "none" }], { duration: 1000, delay: 300 + +el.dataset.intro! * 140, easing: EASE.outExpo, fill: "backwards" }),
    );
  }, []);

  // Analyser loop: cursor pushes a peak, scroll drives energy and parallax.
  useEffect(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const m = { nx: 0.5, ny: 0.4, sx: 0.5, sy: 0.4, moved: false };
    const onMove = (e: PointerEvent) => { m.nx = e.clientX / innerWidth; m.ny = e.clientY / innerHeight; m.moved = true; };
    addEventListener("pointermove", onMove, { passive: true });
    const st: { current: SpecState | null } = { current: null };
    const t0 = performance.now();
    let raf = 0, fr = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const sy = scrollY, vh = innerHeight;
      if (sy > vh * 1.2) return;
      m.sx += (m.nx - m.sx) * 0.06; m.sy += (m.ny - m.sy) * 0.06;
      const sp = Math.min(1, sy / vh);
      if (heroInner.current && !reduced) {
        heroInner.current.style.transform = `translateY(${sy * 0.35}px) scale(${1 - sp * 0.06})`;
        heroInner.current.style.opacity = String(Math.max(0, 1 - sp * 1.3));
      }
      const c = canvas.current && fitCanvas(canvas.current);
      if (!c) return;
      const pk = drawSpectrum(c, st, colorsRef.current, {
        t: reduced ? 0 : now - t0, bandWidth: 15, hmax: 0.92, energy: 1 + sp, mx: m.moved ? m.sx : null, my: m.sy,
      });
      if (++fr % 8 === 0 && readout.current) readout.current.textContent = "PEAK " + hzLabel(pk);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); removeEventListener("pointermove", onMove); };
  }, []);

  let idx = -1;
  return (
    <>
      <SiteHeader overlay onSearch={focusSearch} />
      <section ref={hero} className={s.hero} data-raised={focus}>
        <canvas ref={canvas} className={s.spec} aria-hidden="true" />
        <div className={s.specFade} aria-hidden="true" />
        <div className={s.readouts} aria-hidden="true">
          <span>Analyzer · 96 bands</span>
          <span ref={readout} className={s.live}>PEAK 1.2 kHz</span>
          <span>20 Hz — 20 kHz</span>
        </div>

        <div ref={heroInner} className={s.inner}>
          <div className={s.text}>
            <div data-intro="0" className={s.kicker}>
              <b>{stats.plugins.toLocaleString("en-US")} plugins</b><i />
              <span>{stats.presets.toLocaleString("en-US")} preset packs · {stats.categories} categories</span>
            </div>
            <h1 className={s.h1}>
              {LINES.map((ln, i) => (
                <span key={i} className={s.line}>
                  {ln.map((w) => <span key={w} className={s.mask}><span data-word="">{w}</span></span>)}
                </span>
              ))}
            </h1>
            <p data-intro="1" className={s.sub}>Synths, effects and presets from {stats.developers} developers. Compare formats, check compatibility, and find the right host for every preset.</p>

            <div data-intro="2" className={s.searchWrap}>
              <form className={s.search} onSubmit={submit} role="search">
                <span className={s.glass} aria-hidden="true"><span /><span /></span>
                <input
                  ref={input}
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onFocus={() => setFocus(true)}
                  onBlur={() => setFocus(false)}
                  onKeyDown={onKeyDown}
                  placeholder={PLACEHOLDERS[0]}
                  aria-label="Search plugins and presets"
                  aria-expanded={focus}
                  aria-controls="hero-results"
                  aria-activedescendant={sel >= 0 ? `hit-${sel}` : undefined}
                  role="combobox"
                  autoComplete="off"
                />
                <span className={s.kbd} aria-hidden="true">⌘K</span>
                <button type="submit" data-magnetic="" className={`btn-acc ${s.go}`}>Search</button>
              </form>

              {focus && (
                <div id="hero-results" role="listbox" className={s.drop} onMouseDown={(e) => e.preventDefault()}>
                  {res.groups.map((g) => (
                    <div key={g.label} className={s.group}>
                      <div className={s.groupHead}><span>{g.label}</span><span>{g.count}</span></div>
                      {g.items.map((it) => {
                        idx++;
                        const i = idx;
                        return (
                          <Link
                            key={it.key}
                            id={`hit-${i}`}
                            role="option"
                            aria-selected={sel === i}
                            href={it.href}
                            className={s.hit}
                          >
                            <span className={`${s.thumb} stripes`} />
                            <span className={s.hitText}><span>{it.name}</span><span>{it.meta}</span></span>
                            <span className={s.hitRight}>{it.right}</span>
                          </Link>
                        );
                      })}
                    </div>
                  ))}
                  {res.noResults && (
                    <div className={s.flat}>
                      <div className={s.flatLine} />
                      <div>Flatline. Nothing matches “{q}”.</div>
                      <div>Try a sound instead: warm · glue · shimmer · grit</div>
                    </div>
                  )}
                  <div className={s.dropFoot}><span>↑↓ navigate · ↵ open · esc close</span><span>{res.label}</span></div>
                </div>
              )}

              <div className={s.chips}>
                {SUGGESTIONS.map((x) => (
                  <button key={x} type="button" onClick={() => { setQ(x); focusSearch(); }}>{x}</button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
