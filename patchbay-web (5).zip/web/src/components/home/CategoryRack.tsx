"use client";

import Link from "next/link";
import { useEffect, useRef } from "react";
import { type Motif, drawMotif, fitCanvas } from "@/lib/dsp";
import { useCanvasColors } from "@/lib/theme";
import s from "./home.module.css";

export interface RackCategory { name: string; path: string; count: number; sub: string; motif: Motif }

function Tile({ name, path, count, sub, motif, idx }: RackCategory & { idx: number }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const hot = useRef(false);
  const { acc, ink3 } = useCanvasColors();

  useEffect(() => {
    const c = canvas.current!;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    const t0 = performance.now();
    const draw = (ph: number, on: boolean) => { const f = fitCanvas(c); if (f) drawMotif(f, motif, ph, on ? acc : ink3); };
    const loop = (now: number) => {
      draw(reduced ? 0 : (now - t0) * 0.0012, true);
      if (hot.current) raf = requestAnimationFrame(loop);
    };
    const tile = c.closest("a")!;
    const enter = () => { hot.current = true; cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); };
    const leave = () => { hot.current = false; cancelAnimationFrame(raf); draw(0, false); };
    tile.addEventListener("pointerenter", enter);
    tile.addEventListener("pointerleave", leave);
    tile.addEventListener("focus", enter);
    tile.addEventListener("blur", leave);
    const ro = new ResizeObserver(() => draw(0, hot.current));
    ro.observe(c);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      tile.removeEventListener("pointerenter", enter);
      tile.removeEventListener("pointerleave", leave);
      tile.removeEventListener("focus", enter);
      tile.removeEventListener("blur", leave);
    };
  }, [motif, acc, ink3]);

  return (
    <Link href={path} data-tile="" data-cursor="Open" className={s.catTile}>
      <div className={s.catTop}><span>{String(idx + 1).padStart(2, "0")}</span><span>{count.toLocaleString("en-US")}</span></div>
      <canvas ref={canvas} className={s.catMotif} aria-hidden="true" />
      <div className={s.catName}><span>{name}</span><span>{sub}</span></div>
    </Link>
  );
}

export function CategoryRack({ cats }: { cats: RackCategory[] }) {
  return (
    <div data-rack="" className={s.rack}>
      <div className={s.rackEars} aria-hidden="true"><span /><span /></div>
      <div className={`${s.rackEars} ${s.right}`} aria-hidden="true"><span /><span /></div>
      <div className={s.catGrid}>
        {cats.map((c, i) => <Tile key={c.path} {...c} idx={i} />)}
      </div>
    </div>
  );
}
