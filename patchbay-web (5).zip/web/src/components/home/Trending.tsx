"use client";

import { useRef } from "react";
import { ProductCard } from "@/components/shared/ProductCard";
import type { Item } from "@/lib/data/types";
import s from "./home.module.css";

export function Trending({ products }: { products: Item[] }) {
  const track = useRef<HTMLDivElement>(null);
  const prog = useRef<HTMLDivElement>(null);
  const by = (d: number) => track.current?.scrollBy({ left: d * 680, behavior: "smooth" });
  const onScroll = () => {
    const c = track.current!;
    if (prog.current) prog.current.style.width = 20 + (80 * c.scrollLeft) / Math.max(1, c.scrollWidth - c.clientWidth) + "%";
  };

  return (
    <section className={s.trending} aria-labelledby="trending-h">
      <div data-reveal="" className={`wrap section-head ${s.trendHead}`}>
        <div>
          <div className="eyebrow"><b>02</b><i />Most rated</div>
          <h2 id="trending-h" className="h2">Trending with producers</h2>
        </div>
        <div className={s.arrows}>
          <button type="button" data-magnetic="" aria-label="Previous" onClick={() => by(-1)}>←</button>
          <button type="button" data-magnetic="" aria-label="Next" onClick={() => by(1)}>→</button>
        </div>
      </div>
      <div ref={track} className={s.carousel} onScroll={onScroll}>
        {products.map((p) => <ProductCard key={p.p} p={p} variant="home" className={s.carCard} />)}
      </div>
      <div className="wrap">
        <div className={s.progTrack}><div ref={prog} className={s.prog} /></div>
      </div>
    </section>
  );
}
