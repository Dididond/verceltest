"use client";

import { useState } from "react";
import { Toast, useToast } from "@/components/shared/Toast";
import s from "./home.module.css";

export function Alerts() {
  const [alerts, setAlerts] = useState<Record<string, boolean>>({ Synths: true, Effects: true, Presets: false, Kontakt: true });
  const [email, setEmail] = useState("");
  const [toast, showToast] = useToast();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const on = Object.entries(alerts).filter((x) => x[1]).map((x) => x[0].toLowerCase());
    showToast("Alerts on for " + (on.join(", ") || "everything") + ".");
    setEmail("");
  };

  return (
    <section id="alerts" className={`wrap ${s.section} ${s.alertsSec}`} aria-labelledby="alerts-h">
      <div className={s.alerts}>
        <div data-reveal="" className={s.alertsText}>
          <div className="eyebrow"><b>07</b><i />Release alerts</div>
          <h2 id="alerts-h" className={`h2 ${s.alertsH}`}>Hear about new sounds first.</h2>
          <p>Pick what you care about. We email you about new releases, at most once a week.</p>
        </div>
        <form data-reveal="" className={s.alertForm} onSubmit={submit}>
          <div className={s.alertGrid}>
            {Object.entries(alerts).map(([label, on]) => (
              <button key={label} type="button" role="switch" aria-checked={on} onClick={() => setAlerts((a) => ({ ...a, [label]: !a[label] }))}>
                <span><span className="led" data-on={on} />{label}</span>
                <span className="switch" />
              </button>
            ))}
          </div>
          <div className={s.emailRow}>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@studio.com" aria-label="Email" />
            <button type="submit" data-magnetic="" className="btn-acc">Turn on alerts</button>
          </div>
          <span className={s.fine}>No spam. Unsubscribe in one click.</span>
        </form>
      </div>
      <Toast msg={toast} />
    </section>
  );
}
