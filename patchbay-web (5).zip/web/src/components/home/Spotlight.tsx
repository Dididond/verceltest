"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { LocalKnob } from "@/components/shared/Knob";
import { type SpecState, drawSpectrum, fitCanvas, vnoise } from "@/lib/dsp";
import { useCanvasColors } from "@/lib/theme";
import s from "./home.module.css";

export interface SpotlightDev {
  name: string;
  path: string;
  products: number;
  avgRating: number;
  ratings: number;
  categories: string[];
  top: { name: string; path: string; meta: string; right: string }[];
}

/** Decorative mastering-device mock-up. Playback is visual only. */
function SpotlightDevice({ title, sub }: { title: string; sub: string }) {
  const [playing, setPlaying] = useState(false);
  const canvas = useRef<HTMLCanvasElement>(null);
  const vu = useRef<(HTMLDivElement | null)[]>([]);
  const lufs = useRef<HTMLSpanElement>(null);
  const colors = useCanvasColors();
  const live = useRef({ playing, colors });
  live.current = { playing, colors };

  useEffect(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const st: { current: SpecState | null } = { current: null };
    const t0 = performance.now();
    let raf = 0, fr = 0, visible = false;
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; });
    io.observe(canvas.current!);
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (!visible) return;
      const f = fitCanvas(canvas.current!);
      if (!f) return;
      const { playing: play, colors: col } = live.current, rt = reduced ? 0 : now - t0;
      drawSpectrum(f, st, col, { t: rt, bandWidth: 9, hmax: 0.85, energy: play ? 1.25 : 0.45, mx: null, my: 0 });
      const lv = play ? 0.55 + 0.35 * vnoise(rt * 0.008) : 0.18 + 0.08 * vnoise(rt * 0.004);
      vu.current.forEach((v, i) => { if (v) v.style.height = Math.min(100, (lv + (i ? vnoise(rt * 0.01 + 5) * 0.08 : 0)) * 100) + "%"; });
      if (++fr % 10 === 0 && lufs.current) lufs.current.textContent = (play ? -(9.6 + vnoise(rt * 0.003) * 0.8) : -14).toFixed(1).replace("-", "−") + " LUFS";
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); io.disconnect(); };
  }, []);

  return (
    <div data-tilt="" data-soft="" className={s.device}>
      <div className={s.devHead}>
        <div><span className={s.devName}>{title}</span><span className={s.devSub}>{sub}</span></div>
        <span ref={lufs} className={s.lufs}>−14.0 LUFS</span>
      </div>
      <div className={s.devScreens}>
        <div className={s.screen}><canvas ref={canvas} aria-hidden="true" /></div>
        <div className={s.vuWrap} aria-hidden="true">
          {[0, 1].map((i) => <div key={i} className={s.vu}><div ref={(el) => { vu.current[i] = el; }} /></div>)}
        </div>
      </div>
      <div className={s.devKnobs}>
        <LocalKnob initial={0.55} label="INPUT" unit="db" size={54} />
        <LocalKnob initial={0.4} label="GLUE" unit="pct" size={54} />
        <LocalKnob initial={0.62} label="WIDTH" unit="pct" size={54} />
        <LocalKnob initial={0.92} label="CEILING" unit="ceil" size={54} />
      </div>
      <button type="button" data-cursor="Listen" className={s.play} aria-pressed={playing} onClick={() => setPlaying((p) => !p)}>
        <span className="led" data-on={playing} />{playing ? "PLAYING DEMO · SILENT PREVIEW" : "PLAY DEMO"}
      </button>
    </div>
  );
}

export function Spotlight({ dev }: { dev: SpotlightDev }) {
  const lead = dev.top[0];
  return (
    <section id="developers" className={`wrap ${s.section}`} aria-labelledby="dev-h">
      <div className={s.spot}>
        <div data-reveal="" style={{ perspective: 1400 }}>
          <SpotlightDevice title={lead.name.split(/[\s:–-]+/).slice(0, 2).join(" ").toUpperCase()} sub={lead.meta.split(" · ")[0].toUpperCase()} />
        </div>
        <div data-reveal="" className={s.spotText}>
          <div className="eyebrow"><b>06</b><i />Developer spotlight</div>
          <h2 id="dev-h" className={`h2 ${s.spotH}`}>{dev.name}</h2>
          <p>{dev.products} products in the catalog across {dev.categories.slice(0, 3).join(", ")}{dev.categories.length > 3 ? " and more" : ""}, rated {dev.avgRating.toFixed(1)}/5 on average by Plugin Boutique customers.</p>
          <div className={s.spotStats}>
            <div><span>PRODUCTS</span><span data-count={dev.products}>{dev.products}</span></div>
            <div><span>AVG RATING</span><span data-count={dev.avgRating.toFixed(1)} data-dec="1">{dev.avgRating.toFixed(1)}</span></div>
            <div><span>RATINGS</span><span data-count={dev.ratings}>{dev.ratings.toLocaleString("en-US")}</span></div>
          </div>
          <div className={s.devList}>
            {dev.top.map((d) => (
              <Link key={d.path} href={d.path} data-cursor="View">
                <span><span>{d.name}</span><span>{d.meta}</span></span>
                <span>{d.right}</span>
              </Link>
            ))}
          </div>
          <Link href={dev.path} data-magnetic="" className={s.devAll}>View all {dev.products} products →</Link>
        </div>
      </div>
    </section>
  );
}
