import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductImage, RatingSegs } from "@/components/shared/ProductCard";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";
import { getCardByPath, getItemsByPaths, hasListing } from "@/lib/data/catalog";
import { absoluteImage, mirrored } from "@/lib/data/images";
import type { ProductType } from "@/lib/data/types";
import { ratingText, requiresPath } from "@/lib/format";
import { jsonLd, rehostDeep, toPath } from "@/lib/seo";
import { HeroFloat } from "./HeroFloat";
import { Purchase } from "./Purchase";
import { type BodyData, ProductBody } from "./ProductBody";
import { SectionTabs } from "./SectionTabs";
import s from "./product.module.css";

const paragraphs = (body: string) => body.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);

export function ProductPage({ type, slug }: { type: ProductType; slug: string }) {
  const card = getCardByPath(`/${type}s/${slug}`);
  if (!card) notFound();
  const { product: p, content: ct, store } = card;
  const preset = p.product_type === "preset";
  const name = ct?.h1 ?? p.name;
  const related = getItemsByPaths(card.related.map((r) => r.path));
  const moreFromDev = getItemsByPaths(card.more_from_developer.map((r) => r.path));
  const crumbs = card.breadcrumbs;
  const img = mirrored(p.image_url);
  // Point structured data at our mirrored copy instead of the store's CDN.
  const jsonLdItems = img
    ? card.json_ld.map((ld) => (ld["@type"] === "Product" ? { ...ld, image: [absoluteImage(img)] } : ld))
    : card.json_ld;
  // Prices change on the store side, so the catalog's Offer (with price) is never published.
  const ld = rehostDeep(jsonLdItems.map((x) => (x["@type"] === "Product" ? (({ offers: _offers, ...rest }) => rest)(x) : x)));
  const devLink = hasListing(card.developer.path);
  const reqLink = !!p.requires && preset && hasListing(requiresPath(p.requires));
  const Dev = ({ children, className }: { children: React.ReactNode; className?: string }) =>
    devLink ? <Link href={card.developer.path} className={className}>{children}</Link> : <span className={className}>{children}</span>;

  // Card props are trimmed to what a card renders; they ride in the RSC payload.
  const slim = ({ dp: _dp, s: _s, cp: _cp, ...rest }: (typeof related)[number]) => rest as (typeof related)[number];
  const body: BodyData = {
    intro: ct ? paragraphs(ct.intro) : [],
    useCases: ct?.use_cases ?? [],
    quick: [
      ["Developer", card.developer.name, devLink ? card.developer.path : null],
      ["Category", card.category.label, card.category.path],
      ...(p.requires ? [["Requires", p.requires, reqLink ? requiresPath(p.requires) : null] as BodyData["quick"][number]] : []),
      ["Store", store.name, null],
    ],
    features: ct?.key_features ?? [],
    sections: (ct?.sections ?? []).map((x) => [x.heading, paragraphs(x.body)]),
    specs: card.specs.map((x) => [x.label, x.value]),
    storeName: store.name,
    upgrades: card.upgrade_options.map((u) => [u.name, u.path ?? null, u.store_url]),
    faq: (ct?.faq ?? []).map((f) => [f.question, paragraphs(f.answer)]),
    related: related.map(slim),
    relatedTitle: `Related ${preset ? "preset packs" : "plugins"}`,
    category: [card.category.label, card.category.path],
    more: moreFromDev.map((r) => [r.n, r.p, r.c]),
    developer: [card.developer.name, devLink ? card.developer.path : null],
  };

  const tabs: [string, string][] = [];
  if (ct) tabs.push(["overview", "Overview"]);
  if (ct?.key_features.length) tabs.push(["features", "Features"]);
  if (ct?.sections.length) tabs.push(["details", "In depth"]);
  tabs.push(["specs", "Specs"]);
  if (card.upgrade_options.length) tabs.push(["upgrades", "Upgrades"]);
  if (ct?.faq.length) tabs.push(["faq", "FAQ"]);
  if (related.length || moreFromDev.length) tabs.push(["related", "Related"]);

  return (
    <div className="page">
      {/* og:type=product isn't expressible through the Metadata API; React hoists this into <head>. */}
      <meta property="og:type" content={card.meta["og:type"] ?? "product"} />
      {ld.map((ld, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(ld) }} />
      ))}

      <SiteHeader active={preset ? "presets" : "browse"} />

<main>
      <nav aria-label="Breadcrumb" className={`wrap ${s.crumbs}`}>
        <ol>
          {crumbs.map((b, i) => (
            <li key={b.url}>
              {i < crumbs.length - 1 ? <Link href={toPath(b.url)}>{b.name}</Link> : <span aria-current="page">{b.name}</span>}
            </li>
          ))}
        </ol>
      </nav>

      {card.canonical_product && (
        <div className="wrap">
          <aside className={s.variantNote}>
            <span className="dot-live" />
            <span>This is an upgrade or crossgrade offer for <Link href={card.canonical_product.path}>{card.canonical_product.name}</Link>. See the main product page for the full description, specs and every upgrade option.</span>
            <Link href={card.canonical_product.path} className="pill-link">Main product <span>→</span></Link>
          </aside>
        </div>
      )}

      <section className={`wrap ${s.hero}`}>
        <div className={s.heroCol}>
          <HeroFloat>
            <div className={`${s.shot} stripes`}>
              <ProductImage item={{ n: p.name, im: img?.id ?? null, iw: img?.w ?? 0, ih: img?.h ?? 0 }} alt={ct?.image_alt ?? p.name} hero />
            </div>
          </HeroFloat>
        </div>

        <div className={s.info}>
          <div data-reveal="" className={s.byline}>
            <Dev><span className={s.devDot} />{card.developer.name}</Dev>
            <span>·</span><Link href={card.category.path} className={s.catLink}>{card.category.label}</Link>
            {p.has_trial && <span className={s.trial}>Free trial</span>}
          </div>
          <h1 data-reveal="" className={s.h1}>{name}</h1>
          {store.rating != null && (store.rating_count ?? 0) > 0 && (
            <div data-reveal="" className={s.ratingRow}>
              <RatingSegs rating={store.rating} size="lg" />
              <span className={s.ratingCount}>{ratingText(store.rating, Math.round(store.rating_count!))}</span>
            </div>
          )}
          {ct?.summary && <p data-reveal="" className={s.lede}>{ct.summary}</p>}

          {p.requires && (
            <div data-reveal="" className={s.requires}>
              <span className={s.reqIcon} aria-hidden="true">{p.requires[0]}</span>
              <div>
                <span>REQUIRES</span>
                <span>{p.requires}</span>
                <span>Host {preset ? "synth" : "player"} sold separately</span>
              </div>
              {reqLink && <Link href={requiresPath(p.requires)}>All presets for {p.requires}</Link>}
            </div>
          )}

          {(p.formats.length > 0 || p.os.length > 0 || p.bits) && (
            <div className={s.compat}>
              {p.formats.map((f) => <span key={f} className="badge" style={{ fontSize: 11, padding: "7px 8px" }}>{f}</span>)}
              {p.formats.length > 0 && p.os.length > 0 && <span className={s.sep} />}
              {p.os.map((o) => <span key={o} className={s.osBadge}>{o}</span>)}
              {p.bits && <span className={s.osBadge}>{p.bits}</span>}
            </div>
          )}

          <Purchase name={p.name} developer={p.developer} storeName={store.name} storeUrl={store.url} trial={p.has_trial} />
        </div>
      </section>

      <SectionTabs tabs={tabs} updated={`${p.product_type === "preset" ? "Preset pack" : "Plugin"} · ${card.category.label}`} />

      <ProductBody d={body} />
</main>
      <SiteFooter style={{ marginTop: "clamp(96px,12vw,160px)", paddingBottom: 120 }} />
    </div>
  );
}
