"use client";

import { useEffect, useRef } from "react";
import { EASE } from "@/lib/site";
import s from "./product.module.css";

/** Device frame that floats in and gently follows the cursor. Content is server-rendered. */
export function HeroFloat({ children }: { children: React.ReactNode }) {
  const outer = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    outer.current!.animate([{ opacity: 0, transform: "translateY(50px) rotateX(14deg)" }, { opacity: 1, transform: "none" }], { duration: 1300, easing: EASE.outExpo, fill: "backwards" });
    const m = { nx: 0.5, ny: 0.5, sx: 0.5, sy: 0.5 };
    const onMove = (e: PointerEvent) => { m.nx = e.clientX / innerWidth; m.ny = e.clientY / innerHeight; };
    addEventListener("pointermove", onMove, { passive: true });
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (scrollY > innerHeight) return;
      m.sx += (m.nx - m.sx) * 0.06; m.sy += (m.ny - m.sy) * 0.06;
      frame.current!.style.transform = `rotateY(${(m.sx - 0.5) * -8}deg) rotateX(${(m.sy - 0.5) * 5 + 2}deg) translateY(${Math.sin((now - t0) * 0.0012) * 6}px)`;
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); removeEventListener("pointermove", onMove); };
  }, []);

  return (
    <div ref={outer} style={{ perspective: 1600 }}>
      <div ref={frame} className={s.float} data-vt-target="">
        {children}
        <div className={s.floatGlow} aria-hidden="true" />
      </div>
    </div>
  );
}
