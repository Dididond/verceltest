"use client";

import { useEffect, useRef } from "react";
import s from "./product.module.css";

/** Pinned section nav whose underline follows the section in view. */
export function SectionTabs({ tabs, updated }: { tabs: [string, string][]; updated: string }) {
  const bar = useRef<HTMLDivElement>(null);
  const ind = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    let act: string | null = null, raf = 0, fr = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      if (++fr % 4) return;
      let cur: string | null = null;
      tabs.forEach(([id]) => { const el = document.getElementById(id); if (el && el.getBoundingClientRect().top < 180) cur = id; });
      if (cur === act) return;
      act = cur;
      bar.current!.querySelectorAll<HTMLButtonElement>("[data-tab]").forEach((b) => {
        const on = b.dataset.tab === cur;
        b.setAttribute("aria-current", on ? "true" : "false");
        if (on) {
          ind.current!.style.transform = `translateX(${b.offsetLeft + 10}px)`;
          ind.current!.style.width = b.offsetWidth - 20 + "px";
          const list = bar.current!, l = b.offsetLeft, r = l + b.offsetWidth;
          if (l < list.scrollLeft) list.scrollLeft = l - 12;
          else if (r > list.scrollLeft + list.clientWidth) list.scrollLeft = r - list.clientWidth + 12;
        }
      });
      ind.current!.style.opacity = cur ? "1" : "0";
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [tabs]);

  const go = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    scrollTo({ top: el.getBoundingClientRect().top + scrollY - 130, behavior: reduced ? "auto" : "smooth" });
  };

  return (
    <nav className={s.tabs} aria-label="Sections">
      <div className={`wrap ${s.tabsInner}`}>
        <div ref={bar} className={s.tabList}>
          {tabs.map(([id, label]) => (
            <button key={id} type="button" data-tab={id} onClick={() => go(id)}>{label}</button>
          ))}
          <span ref={ind} className={s.tabInd} aria-hidden="true" />
        </div>
        <span className={s.updated}>Updated {updated}</span>
      </div>
    </nav>
  );
}
