"use client";

import { useEffect, useRef, useState } from "react";
import { EASE } from "@/lib/site";
import s from "./product.module.css";

interface Props {
  name: string;
  developer: string;
  storeName: string;
  storeUrl: string;
  trial: boolean;
}

/** Outbound store link block and the sticky bar. No prices: they change on the store side. */
export function Purchase({ name, developer, storeName, storeUrl, trial }: Props) {
  const [barOn, setBarOn] = useState(false);
  const block = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches)
      block.current!.animate([{ opacity: 0, transform: "translateY(26px)" }, { opacity: 1, transform: "none" }], { duration: 1000, delay: 300, easing: EASE.outExpo, fill: "backwards" });
    // Show the bar once the whole block has scrolled above the header.
    const io = new IntersectionObserver(([e]) => setBarOn(!e.isIntersecting && e.boundingClientRect.top < 0), { rootMargin: "-70px 0px 0px 0px" });
    io.observe(block.current!);
    return () => io.disconnect();
  }, []);

  const label = `View on ${storeName}`;
  return (
    <>
      <div ref={block} className={s.priceBlock}>
        <div className={s.storeHead}>
          <span className={s.storeKicker}><span className="dot-live" />AVAILABLE AT</span>
          <span className={s.storeName}>{storeName}</span>
        </div>
        <div className={s.ctas}>
          <a href={storeUrl} target="_blank" rel="sponsored nofollow noopener" data-magnetic="" className={`btn-acc ${s.buy}`}>
            {label} <span aria-hidden="true">↗</span>
          </a>
        </div>
        <div className={s.priceFoot}>
          <span>{trial ? "Free trial available from the developer" : "Opens the store in a new tab"}</span>
        </div>
      </div>

      <div className={s.buyBar} data-on={barOn} aria-hidden={!barOn}>
        <div>
          <span className={`${s.barThumb} stripes`} />
          <span className={s.barText}>
            <span>{name}</span>
            <span>{developer} · {storeName}</span>
          </span>
          <a href={storeUrl} target="_blank" rel="sponsored nofollow noopener" tabIndex={barOn ? 0 : -1} className={s.barBuy}>View <span aria-hidden="true">↗</span></a>
        </div>
      </div>
    </>
  );
}
