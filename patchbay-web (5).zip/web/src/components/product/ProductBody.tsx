"use client";

import Link from "next/link";
import { ProductCard } from "@/components/shared/ProductCard";
import type { Item } from "@/lib/data/types";
import s from "./product.module.css";

/**
 * Everything below the section tabs. It is a client component only so the
 * RSC payload carries this compact data instead of a full element tree;
 * the server still renders all of it to HTML.
 */
export interface BodyData {
  intro: string[];
  useCases: string[];
  quick: [label: string, value: string, href: string | null][];
  features: string[];
  sections: [heading: string, paragraphs: string[]][];
  specs: [label: string, value: string][];
  storeName: string;
  upgrades: [name: string, path: string | null, storeUrl: string][];
  faq: [question: string, paragraphs: string[]][];
  related: Item[];
  relatedTitle: string;
  category: [label: string, path: string];
  more: [name: string, path: string, category: string][];
  developer: [name: string, path: string | null];
}

const ICONS = ["ring", "square", "grid", "diamond", "bars", "dot"];

function Eyebrow({ n, children }: { n: number; children: React.ReactNode }) {
  return <div className="eyebrow"><b>{String(n).padStart(2, "0")}</b><i />{children}</div>;
}

export function ProductBody({ d }: { d: BodyData }) {
  let n = 0;
  return (
    <div className="wrap">
      {d.intro.length > 0 && (
        <section id="overview" className={s.overview}>
          <div data-reveal="" className={s.ovText}>
            <Eyebrow n={++n}>Overview</Eyebrow>
            {d.intro.map((t, i) => <p key={i} className={i ? s.ovBody : s.ovLead}>{t}</p>)}
          </div>
          <div data-reveal="" className={s.facts}>
            {d.useCases.length > 0 && (
              <div>
                <h2 className={s.factsHead}>Best for</h2>
                <ul className={s.useCases}>{d.useCases.map((u, i) => <li key={i}>{u}</li>)}</ul>
              </div>
            )}
            <dl className={s.quick}>
              {d.quick.map(([k, v, href], i) => <div key={i}><dt>{k}</dt><dd>{href ? <Link href={href}>{v}</Link> : v}</dd></div>)}
            </dl>
          </div>
        </section>
      )}

      {d.features.length > 0 && (
        <section id="features" className={s.sec}>
          <div data-reveal="" style={{ marginBottom: 18 }}><Eyebrow n={++n}>Key features</Eyebrow></div>
          <h2 data-reveal="" className={`h2 ${s.h2}`} style={{ marginBottom: 40 }}>What you get</h2>
          <ul data-rack="" className={s.featureList}>
            {d.features.map((f, i) => (
              <li key={i} data-tile=""><span className={s.ficon}><span data-icon={ICONS[i % ICONS.length]} /></span><span>{f}</span></li>
            ))}
          </ul>
        </section>
      )}

      {d.sections.length > 0 && (
        <section id="details" className={s.sec}>
          <div data-reveal="" style={{ marginBottom: 18 }}><Eyebrow n={++n}>In depth</Eyebrow></div>
          <div className={s.longform}>
            {d.sections.map(([h, ps], i) => (
              <article key={i} data-reveal="" className={s.lfRow}>
                <h2>{h}</h2>
                <div>{ps.map((t, j) => <p key={j}>{t}</p>)}</div>
              </article>
            ))}
          </div>
        </section>
      )}

      <section id="specs" className={`${s.sec} ${s.specs}`}>
        <div data-reveal="" className={s.specIntro}>
          <Eyebrow n={++n}>Specs</Eyebrow>
          <h2 className={`h2 ${s.h2}`}>Will it run?</h2>
          <p>Formats, systems and requirements as listed by {d.storeName}. Missing details are left out, not guessed.</p>
        </div>
        <table data-reveal="" className={s.specTable}>
          <tbody>{d.specs.map(([k, v], i) => <tr key={i} className={s.specRow}><th scope="row">{k}</th><td>{v}</td></tr>)}</tbody>
        </table>
      </section>

      {d.upgrades.length > 0 && (
        <section id="upgrades" className={s.sec}>
          <div data-reveal="" style={{ marginBottom: 18 }}><Eyebrow n={++n}>Upgrades</Eyebrow></div>
          <h2 data-reveal="" className={`h2 ${s.h2}`} style={{ marginBottom: 32 }}>Upgrade and crossgrade options</h2>
          <div className={s.tableScroll}>
            <table data-reveal="" className={s.upgrades}>
              <thead><tr><th scope="col">Option</th><th scope="col"><span className="sr-only">Store link</span></th></tr></thead>
              <tbody>
                {d.upgrades.map(([name, path, url], i) => (
                  <tr key={i}>
                    <td>{path ? <Link href={path}>{name}</Link> : name}</td>
                    <td><a href={url} target="_blank" rel="sponsored nofollow noopener">{d.storeName} ↗</a></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {d.faq.length > 0 && (
        <section id="faq" className={`${s.sec} ${s.faqSec}`}>
          <div data-reveal="" className={s.specIntro}>
            <Eyebrow n={++n}>FAQ</Eyebrow>
            <h2 className={`h2 ${s.h2}`}>Questions, answered</h2>
          </div>
          <div className={s.faq}>
            {d.faq.map(([q, ps], i) => (
              <details key={i} data-reveal="" open={i === 0}>
                <summary><h3>{q}</h3><span aria-hidden="true" /></summary>
                <div>{ps.map((t, j) => <p key={j}>{t}</p>)}</div>
              </details>
            ))}
          </div>
        </section>
      )}

      {d.related.length > 0 && (
        <section id="related" className={s.sec}>
          <div data-reveal="" className="section-head" style={{ marginBottom: 32 }}>
            <div style={{ gap: 18 }}>
              <Eyebrow n={++n}>Related</Eyebrow>
              <h2 className={`h2 ${s.h2}`}>{d.relatedTitle}</h2>
            </div>
            <Link href={d.category[1]} data-magnetic="" className="pill-link">All {d.category[0]} <span>→</span></Link>
          </div>
          <div className={s.similar}>{d.related.map((r) => <ProductCard key={r.p} p={r} />)}</div>
        </section>
      )}

      {d.more.length > 0 && (
        <section id={d.related.length ? undefined : "related"} className={s.sec}>
          <div data-reveal="" className="section-head" style={{ marginBottom: 32 }}>
            <div style={{ gap: 18 }}>
              <Eyebrow n={++n}>Developer</Eyebrow>
              <h2 className={`h2 ${s.h2}`}>More from {d.developer[0]}</h2>
            </div>
            {d.developer[1] && <Link href={d.developer[1]} data-magnetic="" className="pill-link">All {d.developer[0]} products <span>→</span></Link>}
          </div>
          <ul className={s.devList}>
            {d.more.map(([name, path, cat], i) => (
              <li key={i}><Link href={path}><span>{name}</span><span>{cat}</span></Link></li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
