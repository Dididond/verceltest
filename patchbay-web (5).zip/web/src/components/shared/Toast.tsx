"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export function useToast(ms = 3400) {
  const [msg, setMsg] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const show = useCallback((m: string) => {
    clearTimeout(timer.current);
    setMsg(m);
    timer.current = setTimeout(() => setMsg(null), ms);
  }, [ms]);
  useEffect(() => () => clearTimeout(timer.current), []);
  return [msg, show] as const;
}

export function Toast({ msg, top }: { msg: string | null; top?: boolean }) {
  if (!msg) return null;
  return <div key={msg} role="status" className={`toast ${top ? "top" : ""}`}><i />{msg}</div>;
}
