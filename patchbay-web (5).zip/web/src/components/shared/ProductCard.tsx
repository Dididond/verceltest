import Link from "next/link";
import type { Item } from "@/lib/data/types";
import { CARD_W, cardImage, fullImage, monogram } from "@/lib/format";
import s from "./ProductCard.module.css";

/** VU-style 10-segment rating meter, drawn by CSS from a single element. */
export function RatingSegs({ rating, size }: { rating: number | null; size?: "lg" }) {
  const lit = rating ? Math.round(rating * 2) : 0;
  return <span className={`vu ${size === "lg" ? "vu-lg" : ""}`} style={{ "--lit": lit } as React.CSSProperties} aria-hidden="true" />;
}

type ImgItem = Pick<Item, "n" | "im" | "iw" | "ih">;

/** Our mirrored product artwork, or a monogram placeholder when there's no copy yet. */
export function ProductImage({ item, hero, alt }: { item: ImgItem; hero?: boolean; alt?: string }) {
  if (!item.im) {
    return (
      <div className={s.noImg}>
        <span>{monogram(item.n)}</span>
        <span>NO IMAGE YET</span>
      </div>
    );
  }
  if (hero) {
    return (
      <img
        src={fullImage(item.im)}
        srcSet={item.iw > CARD_W ? `${cardImage(item.im)} ${CARD_W}w, ${fullImage(item.im)} ${item.iw}w` : undefined}
        sizes="(max-width: 1000px) 92vw, 640px"
        width={item.iw}
        height={item.ih}
        alt={alt ?? item.n}
        fetchPriority="high"
        decoding="async"
        className={s.img}
      />
    );
  }
  const w = Math.min(CARD_W, item.iw);
  return <img src={cardImage(item.im)} width={w} height={Math.round((w * item.ih) / item.iw)} alt={alt ?? item.n} loading="lazy" decoding="async" className={s.img} />;
}

interface CardProps {
  p: Item;
  /** Home shows the host synth inline as a badge; listings show a corner tag. */
  variant?: "home" | "catalog";
  className?: string;
}

export function ProductCard({ p, variant = "catalog", className }: CardProps) {
  const home = variant === "home";
  const formats = (home && p.r ? [p.r.toUpperCase(), ...p.f] : p.f).slice(0, 5);
  return (
    <Link href={p.p} data-tilt="" data-cursor="View" data-vt-source="" className={`${s.card} ${home ? s.home : ""} ${className ?? ""}`}>
      <div className={`${s.media} stripes`} data-vt-image="" data-meter-slot="">
        <ProductImage item={p} />
        {p.tr && <span className={`tag tag-new ${s.tag}`}>FREE TRIAL</span>}
        {!home && p.r && <span className={s.requires}>REQUIRES {p.r.toUpperCase()}</span>}
      </div>
      <div className={s.body}>
        <div className={s.meta}><span>{p.d}</span><span>{p.c}</span></div>
        <div className={s.name}>{p.n}</div>
        {formats.length > 0 && <div className="badges" data-badges="">{formats.map((f) => <span key={f} className="badge">{f}</span>)}</div>}
        <div className={s.foot}>
          {p.rt != null && p.rc > 0
            ? <div className={s.rating}><RatingSegs rating={p.rt} /><span>{p.rt.toFixed(1)}</span></div>
            : <span className={s.noRating}>NO RATINGS YET</span>}
          <span className={s.count}>{p.rc ? `${p.rc.toLocaleString("en-US")} ratings` : ""}</span>
        </div>
        <div className={s.os}><span>{p.o.join(" · ")}</span><span>{p.t === "preset" ? "Preset pack" : "Plugin"}</span></div>
      </div>
    </Link>
  );
}
