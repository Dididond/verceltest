"use client";

import type { Item } from "@/lib/data/types";
import { ProductCard } from "./ProductCard";

/**
 * A grid of product cards. Client component purely so the RSC payload carries
 * the compact item data instead of each card's element tree; it is still
 * fully server-rendered to HTML.
 */
export function CardGrid({ items, className }: { items: Item[]; className?: string }) {
  return <div className={className}>{items.map((p) => <ProductCard key={p.p} p={p} />)}</div>;
}
