import { BRAND, STORE_NAME } from "@/lib/site";

export function SiteFooter({ style }: { style?: React.CSSProperties }) {
  return (
    <footer className="foot-strip" style={style}>
      <span>© 2026 {BRAND}. Ratings from {STORE_NAME}.</span>
      <span>We may earn a commission from store links.</span>
    </footer>
  );
}
