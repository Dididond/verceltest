"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";

const MAX_WAIT_MS = 800;

type VTDocument = Document & { startViewTransition?: (cb: () => Promise<void>) => unknown };

/**
 * Shared-element transition from a card image to the product hero.
 * Links marked data-vt-source morph their [data-vt-image] into the next
 * page's [data-vt-target]. Browsers without the View Transitions API, and
 * reduced-motion users, get a normal client navigation.
 */
export function ViewTransitions() {
  const router = useRouter();

  useEffect(() => {
    const doc = document as VTDocument;
    if (!doc.startViewTransition) return;

    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const link = (e.target as Element).closest?.<HTMLAnchorElement>("a[data-vt-source]");
      if (!link || link.target === "_blank") return;
      const url = new URL(link.href);
      if (url.origin !== location.origin || url.pathname === location.pathname) return;

      e.preventDefault();
      const img = link.querySelector<HTMLElement>("[data-vt-image]");
      if (img) img.style.viewTransitionName = "pb-hero";
      doc.startViewTransition!(() => new Promise<void>((resolve) => {
        if (img) img.style.viewTransitionName = "";
        // Rendering (and so requestAnimationFrame) is paused while the browser
        // waits for this promise, so watch DOM mutations instead, and never hold
        // the old page frozen for more than MAX_WAIT_MS.
        let done = false;
        const finish = () => { if (done) return; done = true; mo.disconnect(); clearTimeout(timer); resolve(); };
        const before = document.querySelector("[data-vt-target]");
        const arrived = () => {
          const t = document.querySelector("[data-vt-target]");
          return location.pathname === url.pathname && !!t && t !== before;
        };
        const mo = new MutationObserver(() => { if (arrived()) finish(); });
        mo.observe(document.body, { childList: true, subtree: true });
        const timer = setTimeout(finish, MAX_WAIT_MS);
        router.push(url.pathname + url.search + url.hash);
        if (arrived()) finish();
      }));
    };

    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, [router]);

  return null;
}
