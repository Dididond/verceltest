"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { BRAND } from "@/lib/site";
import { toggleTheme } from "@/lib/theme";
import s from "./SiteHeader.module.css";

const NAV = [
  { href: "/browse", label: "Browse", key: "browse" },
  { href: "/plugins", label: "Plugins", key: "plugins" },
  { href: "/presets", label: "Presets", key: "presets" },
  { href: "/developers", label: "Developers", key: "developers" },
  { href: "/browse?sort=Highest+rated", label: "Top rated", key: "top" },
];

export function Logo() {
  return (
    <Link href="/" data-magnetic="" className={s.logo}>
      <span className={s.mark}><span /></span>
      <span className={s.word}>{BRAND}</span>
    </Link>
  );
}

/**
 * `overlay` floats over the Home hero and frosts once the page scrolls;
 * the default sticks to the top of inner pages.
 */
export function SiteHeader({ overlay, active, onSearch }: { overlay?: boolean; active?: string; onSearch?: () => void }) {
  const [scrolled, setScrolled] = useState(!overlay);
  useEffect(() => {
    if (!overlay) return;
    const on = () => setScrolled(scrollY > 30);
    on();
    addEventListener("scroll", on, { passive: true });
    return () => removeEventListener("scroll", on);
  }, [overlay]);

  return (
    <header className={`${s.header} ${overlay ? s.overlay : s.sticky}`} data-frosted={scrolled}>
      <div className={s.inner}>
        <Logo />
        <nav className={s.nav} aria-label="Main">
          {NAV.map((n) =>
            n.key === active ? (
              <Link key={n.key} href={n.href} className={s.active} aria-current="page"><span />{n.label}</Link>
            ) : (
              <Link key={n.key} href={n.href}>{n.label}</Link>
            ),
          )}
        </nav>
        <div className={s.actions}>
          {onSearch && (
            <button type="button" className={s.search} onClick={onSearch}>
              Search<span>⌘K</span>
            </button>
          )}
          <button type="button" className={s.theme} onClick={toggleTheme} aria-label="Toggle theme"><span /></button>
          <Link href="/#alerts" data-magnetic="" className={s.cta}>Get updates</Link>
        </div>
      </div>
    </header>
  );
}
