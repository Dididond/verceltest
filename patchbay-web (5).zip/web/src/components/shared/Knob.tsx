"use client";

import { useRef, useState, type CSSProperties } from "react";

interface KnobProps {
  /** Normalised 0..1. */
  value: number;
  onChange: (v: number) => void;
  /** Fires when a drag or key press settles. */
  onCommit?: (v: number) => void;
  label: string;
  display: string;
  ariaLabel?: string;
  ariaValueText?: string;
  size?: number;
  /** Keyboard step in normalised units. */
  step?: number;
  /** Also count horizontal drag. */
  horizontal?: boolean;
  labelStyle?: CSSProperties;
  valueStyle?: CSSProperties;
}

const clamp = (v: number) => Math.max(0, Math.min(1, v));

export function Knob({ value, onChange, onCommit, label, display, ariaLabel, ariaValueText, size = 58, step = 0.04, horizontal, labelStyle, valueStyle }: KnobProps) {
  const drag = useRef<{ x: number; y: number; v: number; last: number } | null>(null);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    e.currentTarget.focus({ preventScroll: true });
    drag.current = { x: e.clientX, y: e.clientY, v: value, last: value };
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (!d) return;
    const delta = horizontal ? (d.y - e.clientY + (e.clientX - d.x) * 0.5) / 200 : (d.y - e.clientY) / 180;
    d.last = clamp(d.v + delta);
    onChange(d.last);
  };
  const end = () => {
    if (drag.current) { onCommit?.(drag.current.last); drag.current = null; }
  };
  const onKeyDown = (e: React.KeyboardEvent) => {
    const up = e.key === "ArrowUp" || e.key === "ArrowRight", down = e.key === "ArrowDown" || e.key === "ArrowLeft";
    if (!up && !down) return;
    e.preventDefault();
    const v = clamp(value + (up ? step : -step));
    onChange(v);
    onCommit?.(v);
  };

  return (
    <div className="knob-cell">
      <div
        className="knob"
        data-knob=""
        data-cursor="Drag"
        role="slider"
        tabIndex={0}
        aria-label={ariaLabel ?? label}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(value * 100)}
        aria-valuetext={ariaValueText ?? display}
        style={{ "--size": size + "px", "--deg": value * 270 + "deg" } as CSSProperties}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={end}
        onPointerCancel={end}
        onKeyDown={onKeyDown}
      >
        <div className="knob-cap"><div className="knob-ind" /></div>
      </div>
      <span className="knob-label" style={labelStyle}>{label}</span>
      <span className="knob-val" style={valueStyle}>{display}</span>
    </div>
  );
}

/** Display formats used by the synth/mastering knobs. */
export const knobFormat = {
  pct: (v: number) => Math.round(v * 100) + "%",
  hz: (v: number) => {
    const hz = 20 * Math.pow(1000, v);
    return (v > 0.66 ? (hz / 1000).toFixed(1) + "k" : Math.round(hz)) + " Hz";
  },
  db: (v: number) => (v * 24 - 12).toFixed(1) + " dB",
  ceil: (v: number) => (-(1 - v) * 6).toFixed(1) + " dB",
};

/** A self-contained decorative knob for the device mock-ups. */
export function LocalKnob({ initial, label, unit, size, onValue }: { initial: number; label: string; unit: keyof typeof knobFormat; size?: number; onValue?: (v: number) => void }) {
  const [v, setV] = useState(initial);
  return (
    <Knob
      value={v}
      onChange={(n) => { setV(n); onValue?.(n); }}
      label={label}
      display={knobFormat[unit](v)}
      size={size}
    />
  );
}
