"use client";

import { useEffect, useRef } from "react";
import { EASE, pageZoom } from "@/lib/site";

/**
 * Site-wide motion behaviours, attached declaratively through data attributes
 * so server-rendered markup can opt in without becoming a client component:
 *
 *   data-cursor="View"   custom cursor label over an element
 *   data-tilt            3D tilt + cursor glow + spectrum meter on hover (data-soft = gentler)
 *   data-magnetic        element leans toward the cursor
 *   data-reveal          fades up when scrolled into view
 *   data-rack            children marked data-tile assemble in sequence
 *   data-count="1234"    counts up when visible (data-dec for decimals)
 *   data-ends="3600"     live countdown, seconds from page load
 *   data-bar="64"        inner element fills to 64% when visible
 */

interface Spring { x: number; y: number; vx: number; vy: number; tx: number; ty: number }
const spring = (): Spring => ({ x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: 0 });
const step = (s: Spring) => {
  s.vx += (s.tx - s.x) * 0.12; s.vy += (s.ty - s.y) * 0.12;
  s.vx *= 0.72; s.vy *= 0.72;
  s.x += s.vx; s.y += s.vy;
  return Math.abs(s.x) + Math.abs(s.y) + Math.abs(s.vx) + Math.abs(s.vy) < 0.01;
};

function fmtCountdown(sec: number) {
  let r = Math.max(0, sec);
  const d = Math.floor(r / 86400);
  r %= 86400;
  const s = [Math.floor(r / 3600), Math.floor((r % 3600) / 60), r % 60].map((x) => String(x).padStart(2, "0")).join(":");
  return d ? `${d}d ${s}` : s;
}

export function MotionLayer() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const inner = useRef<HTMLDivElement>(null);
  const label = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const fine = matchMedia("(hover: hover) and (pointer: fine)").matches;
    const root = document.documentElement;
    if (fine) root.classList.add("has-cursor");

    const m = { x: -100, y: -100 }, rp = { x: -100, y: -100 };
    const tilts = new Map<HTMLElement, Spring>();
    const mags = new Map<HTMLElement, Spring>();
    let hov: HTMLElement | null = null;
    let cs: string | null = null;
    const t0 = performance.now();
    const pageStart = Date.now();
    let zoom = pageZoom();
    const onResize = () => { zoom = pageZoom(); };
    addEventListener("resize", onResize);

    const setCursor = (st: string) => {
      if (st === cs || !inner.current) return;
      cs = st;
      const big = !!st && st !== "link" && st !== "text";
      inner.current.style.transform = big ? "scale(1)" : st === "link" ? "scale(.62)" : st === "text" ? "scale(.25)" : "scale(.42)";
      inner.current.style.background = big ? "var(--acc)" : "transparent";
      inner.current.style.borderColor = big || st === "link" ? "var(--acc)" : "var(--ink3)";
      label.current!.textContent = big ? (st === "Listen" || st === "Play" ? "▶ " + st : st) : "";
      label.current!.style.opacity = big ? "1" : "0";
      dot.current!.style.opacity = big ? "0" : "1";
    };

    const enterCard = (card: HTMLElement) => {
      if (!tilts.has(card)) tilts.set(card, spring());
      card.classList.add("is-hot");
      // Cards don't ship the hover meter in their HTML; add it on first hover.
      const slot = card.querySelector<HTMLElement>("[data-meter-slot]");
      if (slot && !slot.querySelector("[data-meter]")) {
        const meter = document.createElement("div");
        meter.dataset.meter = "";
        meter.setAttribute("aria-hidden", "true");
        meter.innerHTML = "<span></span>".repeat(12);
        slot.append(meter);
      }
      card.querySelectorAll<HTMLElement>("[data-badges] > *").forEach((b, i) =>
        b.animate([{ opacity: 0, transform: "translateX(-10px)" }, { opacity: 1, transform: "none" }], { duration: 500, delay: i * 45, easing: EASE.spring, fill: "backwards" }),
      );
    };
    const leaveCard = (card: HTMLElement) => {
      const s = tilts.get(card);
      if (s) { s.tx = 0; s.ty = 0; }
      card.classList.remove("is-hot");
    };

    const onMove = (e: PointerEvent) => {
      m.x = e.clientX; m.y = e.clientY;
      kick();
      const t = e.target instanceof Element ? e.target : document.body;
      const lab = t.closest<HTMLElement>("[data-cursor]");
      setCursor(lab ? lab.dataset.cursor! : t.closest("input,textarea") ? "text" : t.closest("a,button,[role=switch]") ? "link" : "");
      if (!fine || reduced) return;
      const card = t.closest<HTMLElement>("[data-tilt]");
      if (card !== hov) {
        if (hov) leaveCard(hov);
        hov = card;
        if (card) enterCard(card);
      }
      if (card) {
        const r = card.getBoundingClientRect(), px = (m.x - r.left) / r.width, py = (m.y - r.top) / r.height;
        const s = tilts.get(card)!, amt = card.dataset.soft != null ? 6 : 10;
        s.tx = (px - 0.5) * amt; s.ty = -(py - 0.5) * amt;
        card.style.setProperty("--mx", px * 100 + "%");
        card.style.setProperty("--my", py * 100 + "%");
      }
      document.querySelectorAll<HTMLElement>("[data-magnetic]").forEach((el) => {
        let s = mags.get(el);
        if (!s) { s = spring(); mags.set(el, s); }
        const r = el.getBoundingClientRect(), cx = r.left + r.width / 2 - s.x, cy = r.top + r.height / 2 - s.y;
        const dx = m.x - cx, dy = m.y - cy, inside = Math.abs(dx) < r.width / 2 + 28 && Math.abs(dy) < r.height / 2 + 28;
        s.tx = inside ? dx * 0.26 : 0; s.ty = inside ? dy * 0.32 : 0;
      });
    };
    const onLeave = () => { m.x = m.y = -100; };

    // --- Scroll-triggered behaviours ---
    const countUp = (el: HTMLElement) => {
      const n = +el.dataset.count!, dec = +(el.dataset.dec || 0);
      const fmt = (v: number) => (dec ? v.toFixed(dec) : Math.round(v).toLocaleString("en-US"));
      if (reduced) { el.textContent = fmt(n); return; }
      const start = performance.now();
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / 1800), e = 1 - Math.pow(2, -10 * p);
        el.textContent = fmt(p < 1 ? n * e : n);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    const enter = (el: HTMLElement) => {
      if (el.dataset.count != null) return countUp(el);
      if (el.dataset.bar != null) {
        const f = el.firstElementChild as HTMLElement | null;
        if (f) requestAnimationFrame(() => { f.style.width = el.dataset.bar + "%"; });
        return;
      }
      if (reduced) return;
      if (el.dataset.rack != null) {
        el.querySelectorAll<HTMLElement>("[data-tile]").forEach((t, i) =>
          t.animate([{ opacity: 0, transform: "translateY(46px) scale(.94)" }, { opacity: 1, transform: "none" }], { duration: 900, delay: 80 + i * 55, easing: EASE.spring, fill: "backwards" }),
        );
        return;
      }
      el.animate([{ opacity: 0, transform: "translateY(32px)" }, { opacity: 1, transform: "none" }], { duration: 1000, easing: EASE.outExpo, fill: "backwards" });
    };
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => { if (e.isIntersecting) { io.unobserve(e.target); enter(e.target as HTMLElement); } }),
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
    );
    const seen = new WeakSet<Element>();
    const scan = () => {
      document.querySelectorAll<HTMLElement>("[data-reveal],[data-rack],[data-count],[data-bar]").forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        io.observe(el);
      });
      countdowns();
    };
    const countdowns = () => {
      const elapsed = Math.floor((Date.now() - pageStart) / 1000);
      document.querySelectorAll<HTMLElement>("[data-ends]").forEach((el) => {
        el.textContent = fmtCountdown(+el.dataset.ends! - elapsed);
      });
    };
    let scanQueued = false;
    // Only element insertions matter; text updates (live readouts) are ignored
    // so they don't trigger a full-document scan several times a second.
    const mo = new MutationObserver((records) => {
      if (scanQueued || !records.some((r) => [...r.addedNodes].some((n) => n.nodeType === 1))) return;
      scanQueued = true;
      requestAnimationFrame(() => { scanQueued = false; scan(); });
    });
    mo.observe(document.body, { childList: true, subtree: true });
    scan();
    const cd = setInterval(countdowns, 1000);

    // --- Frame loop: cursor, tilt springs, magnetic springs, hover meters ---
    // Runs only while something is moving; pointer movement restarts it.
    let raf = 0, running = false;
    const kick = () => { if (!running) { running = true; raf = requestAnimationFrame(tick); } };
    const tick = (now: number) => {
      const t = now - t0;
      let active = !!hov;
      if (fine && dot.current && ring.current) {
        active ||= Math.abs(m.x - rp.x) + Math.abs(m.y - rp.y) > 0.3;
        rp.x += (m.x - rp.x) * 0.2; rp.y += (m.y - rp.y) * 0.2;
        // Pointer coords are unzoomed viewport px; fixed children of a zoomed <html> are scaled.
        const z = zoom;
        dot.current.style.transform = `translate(${m.x / z}px,${m.y / z}px)`;
        ring.current.style.transform = `translate(${rp.x / z}px,${rp.y / z}px)`;
      }
      if (hov && !hov.isConnected) { tilts.delete(hov); hov = null; }
      tilts.forEach((s, el) => {
        const done = step(s);
        el.style.transform = `perspective(1000px) rotateX(${s.y}deg) rotateY(${s.x}deg)` + (el === hov ? " translateY(-4px)" : "");
        if (done && el !== hov) { el.style.transform = ""; tilts.delete(el); }
        if (el === hov) el.querySelectorAll<HTMLElement>("[data-meter] > span").forEach((b, i) => {
          b.style.height = 14 + 86 * Math.abs(Math.sin(t * 0.005 * (1 + i * 0.17) + i * 1.3)) * (1 - i / 16) + "%";
        });
      });
      if (tilts.size) active = true;
      mags.forEach((s, el) => {
        if (!el.isConnected) { mags.delete(el); return; }
        if (!step(s) || s.tx || s.ty) active = true;
        el.style.transform = Math.abs(s.x) + Math.abs(s.y) > 0.05 ? `translate(${s.x / zoom}px,${s.y / zoom}px)` : "";
      });
      if (active) raf = requestAnimationFrame(tick);
      else running = false;
    };

    addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerleave", onLeave);
    return () => {
      cancelAnimationFrame(raf);
      clearInterval(cd);
      io.disconnect();
      mo.disconnect();
      removeEventListener("pointermove", onMove);
      removeEventListener("resize", onResize);
      document.removeEventListener("pointerleave", onLeave);
      root.classList.remove("has-cursor");
    };
  }, []);

  return (
    <>
      <div ref={dot} className="cursor-dot" aria-hidden="true" />
      <div ref={ring} className="cursor-ring" aria-hidden="true">
        <div ref={inner} className="cursor-inner"><span ref={label} className="cursor-label" /></div>
      </div>
    </>
  );
}
