"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { Item, ProductType } from "@/lib/data/types";
import { type Filters, DEFAULT_FILTERS, FORMATS, OSES, matches } from "@/lib/filters";
import s from "./catalog.module.css";

export interface CatFacet { name: string; path: string; type: ProductType; count: number }

const TYPES = [["all", "All"], ["plugin", "Plugins"], ["preset", "Presets"]] as const;
const RATINGS = [0, 3, 3.5, 4, 4.5];
const CAT_PREVIEW = 12;

interface Props {
  f: Filters;
  apply: (patch: Partial<Filters>) => void;
  total: number;
  /** Bottom-sheet state below 1080px; the sidebar ignores it. */
  open: boolean;
  onClose: () => void;
  /** Full slim index once loaded; until then facet counts come from the server. */
  all: Item[] | null;
  categories: CatFacet[];
  synths: { name: string; count: number }[];
}

export function FilterPanel({ f, apply, total, open, onClose, all, categories, synths }: Props) {
  const [allCats, setAllCats] = useState(false);

  const tog = <K extends "cats" | "formats" | "os">(key: K, v: string) => {
    const arr = f[key];
    apply({ [key]: arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v] } as Partial<Filters>);
  };

  // Live facet counts against the other active filters.
  const counts = useMemo(() => {
    if (!all) return null;
    const cat = new Map<string, number>();
    let trial = 0;
    for (const i of all) {
      if (matches(i, f, "cats")) cat.set(i.cp, (cat.get(i.cp) ?? 0) + 1);
      if (i.tr && matches(i, f, "trial")) trial++;
    }
    return { cat, trial };
  }, [all, f]);

  // Drag the sheet handle down to dismiss.
  const sheet = useRef<HTMLElement>(null);
  const drag = useRef<{ y: number; dy: number } | null>(null);
  const onHandleDown = (e: React.PointerEvent) => {
    if ((e.target as Element).closest("button")) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { y: e.clientY, dy: 0 };
    sheet.current!.style.transition = "none";
  };
  const onHandleMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    drag.current.dy = Math.max(0, e.clientY - drag.current.y);
    sheet.current!.style.transform = `translateY(${drag.current.dy}px)`;
  };
  const onHandleUp = () => {
    if (!drag.current) return;
    const el = sheet.current!;
    el.style.transition = "";
    el.style.transform = "";
    if (drag.current.dy > 110) onClose();
    drag.current = null;
  };

  const typeIdx = TYPES.findIndex(([v]) => v === f.type);
  const rIdx = RATINGS.indexOf(f.rating);
  const cats = categories.filter((c) => f.type === "all" || c.type === f.type);
  const shownCats = allCats ? cats : cats.filter((c, i) => i < CAT_PREVIEW || f.cats.includes(c.path));
  const switches = [
    ["trial", "Free trial available", counts ? `${counts.trial.toLocaleString("en-US")} with trials` : "Try before you buy"],
  ] as const;

  return (
    <aside ref={sheet} className={s.panel} data-open={open} aria-label="Filters">
      <div className={s.sheetHandle} onPointerDown={onHandleDown} onPointerMove={onHandleMove} onPointerUp={onHandleUp} onPointerCancel={onHandleUp}>
        <div className={s.grip} />
        <div className={s.sheetTitle}>
          <span>Filters</span>
          <button type="button" aria-label="Close filters" onClick={onClose}>×</button>
        </div>
      </div>

      <div className={s.panelBody}>
        <div className={s.group} style={{ paddingTop: 0 }}>
          <div className={s.groupHead}><span>TYPE</span></div>
          <div className={s.typeSwitch}>
            <span className={s.typeThumb} style={{ transform: `translateX(${typeIdx * 100}%)` }} aria-hidden="true" />
            {TYPES.map(([v, label]) => (
              <button key={v} type="button" aria-pressed={f.type === v} onClick={() => apply({ type: v, cats: f.cats.filter((c) => v === "all" || c.startsWith(`/${v}s/`)) })}>{label}</button>
            ))}
          </div>
        </div>

        <div className={s.group} style={{ gap: 6 }}>
          <div className={s.groupHead} style={{ marginBottom: 6 }}><span>CATEGORY</span><span>{f.cats.length ? `${f.cats.length} SELECTED` : "ALL"}</span></div>
          {shownCats.map((c) => {
            const on = f.cats.includes(c.path);
            const n = counts ? counts.cat.get(c.path) ?? 0 : c.count;
            return (
              <button key={c.path} type="button" aria-pressed={on} className={s.cat} data-empty={!n && !on} onClick={() => tog("cats", c.path)}>
                <span><span className="led" data-on={on} />{c.name}</span>
                <span className={s.catN}>{n.toLocaleString("en-US")}</span>
              </button>
            );
          })}
          {cats.length > CAT_PREVIEW && (
            <button type="button" className={s.showAll} onClick={() => setAllCats((v) => !v)} aria-expanded={allCats}>
              {allCats ? "Show fewer" : `Show all ${cats.length} categories`}
            </button>
          )}
        </div>

        {f.type !== "plugin" && (
          <div className={s.group}>
            <div className={s.groupHead}><span>PRESETS FOR</span><span>{synths.length} SYNTHS</span></div>
            <label className={s.selectWrap}>
              <span className="sr-only">Host synth or sampler</span>
              <select value={f.requires} onChange={(e) => apply({ requires: e.target.value })}>
                <option value="">Any synth or sampler</option>
                {synths.map((r) => <option key={r.name} value={r.name}>{r.name} ({r.count})</option>)}
              </select>
            </label>
          </div>
        )}


        <div className={s.group} style={{ gap: 8 }}>
          {switches.map(([k, label, n]) => (
            <button key={k} type="button" role="switch" aria-checked={f[k]} className={s.switchRow} onClick={() => apply({ [k]: !f[k] })}>
              <span><span>{label}</span><span>{n}</span></span>
              <span className="switch lg" />
            </button>
          ))}
        </div>

        <div className={s.group}>
          <div className={s.groupHead}><span>FORMATS</span><span>MUST SUPPORT ALL</span></div>
          <div className={s.keys}>
            {FORMATS.map((x) => (
              <button key={x} type="button" className={s.key} aria-pressed={f.formats.includes(x)} onClick={() => tog("formats", x)}>
                <span className="led" data-on={f.formats.includes(x)} />{x}
              </button>
            ))}
          </div>
        </div>

        <div className={s.group}>
          <div className={s.groupHead}><span>OPERATING SYSTEM</span></div>
          <div className={s.osKeys}>
            {OSES.map((o) => (
              <button key={o} type="button" className={s.key} aria-pressed={f.os.includes(o)} onClick={() => tog("os", o)}>
                <span className="led" data-on={f.os.includes(o)} />{o}
              </button>
            ))}
          </div>
        </div>

        <div className={s.group} style={{ gap: 14, borderBottom: 0 }}>
          <div className={s.groupHead}><span>STORE RATING</span><span style={{ color: "var(--ink)" }}>{f.rating ? f.rating.toFixed(1) + " and up" : "Any"}</span></div>
          <div role="radiogroup" aria-label="Minimum store rating" className={s.ratingMeter}>
            {RATINGS.map((v, i) => (
              <button key={v} type="button" role="radio" aria-checked={f.rating === v} aria-label={v ? `${v} stars and up` : "Any rating"} onClick={() => apply({ rating: v })}>
                <span className={s.rBar} data-on={i <= rIdx} style={{ height: 10 + i * 9, transitionDelay: i * 40 + "ms" }} />
                <span>{v ? v.toFixed(1) : "Any"}</span>
              </button>
            ))}
          </div>
        </div>

        <button type="button" className={s.resetDesk} onClick={() => apply({ ...DEFAULT_FILTERS })}>Reset all filters</button>
      </div>

      <div className={s.sheetFoot}>
        <button type="button" className={s.sheetReset} onClick={() => apply({ ...DEFAULT_FILTERS })}>Reset</button>
        <button type="button" className={s.sheetShow} onClick={onClose}>Show {total.toLocaleString("en-US")} results</button>
      </div>
    </aside>
  );
}
