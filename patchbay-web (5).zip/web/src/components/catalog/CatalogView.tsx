"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { ProductCard, ProductImage, RatingSegs } from "@/components/shared/ProductCard";
import type { Item } from "@/lib/data/types";
import { type Filters, type Sort, DEFAULT_FILTERS, PAGE_SIZE, SORTS, activeChips, filtersToQuery, results } from "@/lib/filters";
import { EASE } from "@/lib/site";
import { useCatalogIndex } from "@/lib/useCatalogIndex";
import { useFlip } from "@/lib/useFlip";
import { EmptyState } from "./EmptyState";
import { type CatFacet, FilterPanel } from "./FilterPanel";
import s from "./catalog.module.css";

interface Props {
  initial: Filters;
  initialSort: Sort;
  /** Server-rendered first page for the initial filters. */
  initialItems: Item[];
  initialTotal: number;
  categories: CatFacet[];
  synths: { name: string; count: number }[];
}

export function CatalogView({ initial, initialSort, initialItems, initialTotal, categories, synths }: Props) {
  const [f, setF] = useState<Filters>(initial);
  const [sort, setSort] = useState<Sort>(initialSort);
  const [sortOpen, setSortOpen] = useState(false);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [page, setPage] = useState(1);
  const [sheet, setSheet] = useState(false);
  const [flipTick, setFlipTick] = useState(0);
  const [dirty, setDirty] = useState(false);
  const all = useCatalogIndex();

  const resultsRef = useRef<HTMLDivElement>(null);
  const countRef = useRef<HTMLSpanElement>(null);
  const sortMenu = useRef<HTMLDivElement>(null);
  const capture = useFlip(resultsRef, flipTick);

  const res = useMemo(() => (all ? results(all, f, sort) : null), [all, f, sort]);
  const total = res ? res.length : initialTotal;
  // Until the index arrives, the server-rendered page stands in for the initial filters.
  const shown = res ? res.slice(0, page * PAGE_SIZE) : dirty ? [] : initialItems;
  const waiting = !res && dirty;
  const catLabel = (p: string) => categories.find((c) => c.path === p)?.name ?? p;
  const chips = activeChips(f, catLabel);

  /** Every filter/sort/view change goes through here so results reflow with FLIP. */
  const apply = (patch: Partial<Filters>, extra?: { sort?: Sort; view?: "grid" | "list" }) => {
    capture();
    setF((cur) => ({ ...cur, ...patch }));
    if (extra?.sort) setSort(extra.sort);
    if (extra?.view) setView(extra.view);
    setPage(1);
    setDirty(true);
    setFlipTick((t) => t + 1);
  };

  // Keep the URL shareable. Filtered URLs are noindex on the server side.
  useEffect(() => {
    if (!dirty) return;
    const q = filtersToQuery(f, sort);
    history.replaceState(history.state, "", q ? `/browse?${q}` : "/browse");
  }, [f, sort, dirty]);

  // Animated result count.
  const lastN = useRef(total);
  useEffect(() => {
    const el = countRef.current, a = lastN.current, n = total;
    lastN.current = n;
    if (!el || a === n || matchMedia("(prefers-reduced-motion: reduce)").matches) { if (el) el.textContent = n.toLocaleString("en-US"); return; }
    const t0 = performance.now();
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / 500), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(a + (n - a) * e).toLocaleString("en-US");
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [total]);

  // A new page of results fades up in sequence.
  const prevPage = useRef(page);
  useEffect(() => {
    if (page > prevPage.current && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
      const els = [...(resultsRef.current?.querySelectorAll<HTMLElement>("[data-flip]") ?? [])].slice((page - 1) * PAGE_SIZE);
      els.forEach((el, i) => el.animate([{ opacity: 0, transform: "translateY(24px)" }, { opacity: 1, transform: "none" }], { duration: 600, delay: Math.min(i, 12) * 40, easing: EASE.outExpo, fill: "backwards" }));
    }
    prevPage.current = page;
  }, [page]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { setSheet(false); setSortOpen(false); } };
    addEventListener("keydown", onKey);
    return () => removeEventListener("keydown", onKey);
  }, []);

  // Lock page scroll behind the open sheet.
  useEffect(() => {
    document.documentElement.style.overflow = sheet ? "hidden" : "";
    return () => { document.documentElement.style.overflow = ""; };
  }, [sheet]);

  const lastChip = chips[chips.length - 1];
  const remaining = total - shown.length;

  return (
    <>
      <section className={`wrap ${s.head}`}>
        <div data-reveal="" className={s.titleBlock}>
          <div className="eyebrow"><Link href="/" className={s.crumb}>Home</Link><span>/</span><b>Browse</b></div>
          <h1 className={s.h1}>Browse<span className={s.count}><span ref={countRef}>{total.toLocaleString("en-US")}</span> results</span></h1>
        </div>
        <div className={s.within}>
          <span className={s.glass} aria-hidden="true"><span /><span /></span>
          <input
            value={f.q}
            onChange={(e) => { setF((c) => ({ ...c, q: e.target.value })); setPage(1); setDirty(true); }}
            placeholder="Search within results"
            aria-label="Search within results"
          />
          {f.q && <button type="button" aria-label="Clear search" onClick={() => apply({ q: "" })}>×</button>}
        </div>
      </section>

      <div className={`wrap ${s.layout}`}>
        {sheet && <div className={s.backdrop} onClick={() => setSheet(false)} aria-hidden="true" />}
        <FilterPanel f={f} apply={apply} total={total} open={sheet} onClose={() => setSheet(false)} all={all} categories={categories} synths={synths} />

        <div className={s.results}>
          <div className={s.toolbar}>
            <div className={s.toolLeft}>
              <button type="button" className={s.filtersBtn} onClick={() => setSheet(true)} aria-haspopup="dialog">
                Filters<span>{chips.length}</span>
              </button>
              <span className={s.showing} aria-live="polite">{waiting ? "Loading…" : total ? `Showing ${shown.length.toLocaleString("en-US")} of ${total.toLocaleString("en-US")}` : "No results"}</span>
            </div>
            <div className={s.toolRight}>
              <div className={s.sortWrap}>
                <button
                  type="button"
                  className={s.sortBtn}
                  aria-haspopup="listbox"
                  aria-expanded={sortOpen}
                  onClick={() => setSortOpen((o) => !o)}
                  onBlur={(e) => { if (!sortMenu.current?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
                >
                  <span className={s.sortKey}>SORT</span>{sort}<span className={s.caret}>▼</span>
                </button>
                {sortOpen && (
                  <div ref={sortMenu} role="listbox" aria-label="Sort by" className={s.sortMenu} onMouseDown={(e) => e.preventDefault()}>
                    {SORTS.map((o) => (
                      <button key={o} type="button" role="option" aria-selected={sort === o} onClick={() => { setSortOpen(false); apply({}, { sort: o }); }}>
                        <span>{o}</span><span className="led" data-on={sort === o} />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div role="group" aria-label="View" className={s.viewToggle} data-view={view}>
                <span className={s.viewThumb} aria-hidden="true" />
                <button type="button" aria-pressed={view === "grid"} aria-label="Grid view" onClick={() => apply({}, { view: "grid" })}>
                  <span className={s.gridIcon}><i /><i /><i /><i /></span>
                </button>
                <button type="button" aria-pressed={view === "list"} aria-label="List view" onClick={() => apply({}, { view: "list" })}>
                  <span className={s.listIcon}><i /><i /><i /></span>
                </button>
              </div>
            </div>
          </div>

          {chips.length > 0 && (
            <div className={s.chips}>
              {chips.map((c) => (
                <button key={c.key} type="button" className={s.chip} aria-label={`Remove ${c.label}`} onClick={() => apply(c.undo)}>
                  {c.label}<span aria-hidden="true">×</span>
                </button>
              ))}
              <button type="button" className={s.clearAll} onClick={() => apply({ ...DEFAULT_FILTERS })}>Clear all</button>
            </div>
          )}

          <div ref={resultsRef}>
            {!waiting && total === 0 && (
              <EmptyState lastChip={lastChip?.label} onRemoveLast={() => lastChip && apply(lastChip.undo)} onReset={() => apply({ ...DEFAULT_FILTERS })} />
            )}

            {view === "grid" && (waiting || total > 0) && (
              <div className={s.grid}>
                {shown.map((p) => <div key={p.p} data-flip={p.p} className={s.cell}><ProductCard p={p} /></div>)}
                {waiting && Array.from({ length: 9 }, (_, i) => <SkeletonCard key={"sk" + i} i={i} />)}
              </div>
            )}

            {view === "list" && !waiting && total > 0 && (
              <div className={s.list}>
                {shown.map((p) => <div key={p.p} data-flip={p.p}><ListRow p={p} /></div>)}
              </div>
            )}
          </div>

          {!waiting && remaining > 0 && (
            <div className={s.more}>
              <div className={s.moreTrack}><div style={{ width: (shown.length / Math.max(1, total)) * 100 + "%" }} /></div>
              {res ? (
                <button type="button" data-magnetic="" className="btn-ghost" onClick={() => setPage((p) => p + 1)}>
                  Load {Math.min(PAGE_SIZE, remaining)} more
                </button>
              ) : (
                <span className={s.showing}>Loading the full catalog…</span>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function ListRow({ p }: { p: Item }) {
  return (
    <Link href={p.p} data-cursor="View" data-vt-source="" className={s.row}>
      <div className={`${s.rowImg} stripes`} data-vt-image="">
        <ProductImage item={p} />
        {p.tr && <span className={`tag tag-new ${s.rowTag}`}>TRIAL</span>}
      </div>
      <div className={s.rowMain}>
        <span className={s.rowMeta}>{p.d} · {p.c}</span>
        <span className={s.rowName}>{p.n}</span>
        <span className="badges">
          {p.r && <span className="badge" style={{ borderColor: "var(--acc)", color: "var(--ink)" }}>REQUIRES {p.r.toUpperCase()}</span>}
          {p.f.slice(0, 6).map((x) => <span key={x} className="badge">{x}</span>)}
        </span>
      </div>
      <div className={s.rowSpecs}>
        <span>{p.o.join(" · ") || "—"}</span>
        {p.rt != null && p.rc > 0 ? (
          <span className={s.rowRating}><RatingSegs rating={p.rt} /><span>{p.rt.toFixed(1)}</span></span>
        ) : <span>NO RATINGS YET</span>}
        <span>{p.rc ? `${p.rc.toLocaleString("en-US")} ratings` : ""}</span>
      </div>
      <div className={s.rowPrice}>
        <span>{p.rt != null && p.rc > 0 ? `★ ${p.rt.toFixed(1)}` : "—"}</span>
        <span className={s.rowType}>{p.t === "preset" ? "Preset pack" : "Plugin"}</span>
      </div>
    </Link>
  );
}

/** Skeleton with a meter-sweep shimmer and a lighting rating meter. */
function SkeletonCard({ i }: { i: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = ref.current!;
    const anims = [
      el.querySelector("[data-sweep]")!.animate([{ transform: "translateX(-100%)" }, { transform: "translateX(100%)" }], { duration: 1300, delay: i * 90, iterations: Infinity, easing: "cubic-bezier(.4,0,.2,1)" }),
      ...[...el.querySelectorAll<HTMLElement>("[data-seg]")].map((sg, j) =>
        sg.animate([{ opacity: 0.18 }, { opacity: 1, offset: 0.15 }, { opacity: 0.18, offset: 0.4 }, { opacity: 0.18 }], { duration: 1300, delay: i * 90 + j * 45, iterations: Infinity }),
      ),
    ];
    return () => anims.forEach((a) => a.cancel());
  }, [i]);

  return (
    <div ref={ref} className={s.skel} aria-hidden="true">
      <div className={s.skImg} />
      <div className={s.skBody}>
        <div style={{ width: "45%", height: 10 }} />
        <div style={{ width: "85%", height: 18 }} />
        <div className={s.skBadges}><span style={{ width: 36 }} /><span style={{ width: 28 }} /><span style={{ width: 36 }} /></div>
        <div className={s.skFoot}>
          <span />
          <span className={s.skSegs}>{Array.from({ length: 10 }, (_, j) => <span key={j} data-seg="" />)}</span>
        </div>
      </div>
      <div data-sweep="" className={s.sweep} />
    </div>
  );
}
