"use client";

import { useEffect, useRef } from "react";
import { fitCanvas } from "@/lib/dsp";
import { useCanvasColors } from "@/lib/theme";
import s from "./catalog.module.css";

/** A flatline with a single blip travelling across it. */
function Flatline() {
  const canvas = useRef<HTMLCanvasElement>(null);
  const { acc } = useCanvasColors();
  const accRef = useRef(acc);
  accRef.current = acc;

  useEffect(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const f = fitCanvas(canvas.current!);
      if (!f) return;
      const { ctx: x, w, h } = f, t = now - t0, a = accRef.current;
      x.clearRect(0, 0, w, h);
      const ph = reduced ? -1 : ((t % 2600) / 2600) * 1.4 - 0.2, cy = h * 0.55;
      x.beginPath();
      for (let px = 0; px <= w; px += 2) {
        const u = px / w, k = (u - ph) * 40;
        const y = cy - (Math.abs(k) < 1.5 ? Math.sin(k * Math.PI * 1.4) * Math.exp(-k * k * 0.8) * h * 0.28 : 0) - Math.sin(u * 90 + t * 0.01) * 0.6;
        px ? x.lineTo(px, y) : x.moveTo(px, y);
      }
      x.strokeStyle = a; x.lineWidth = 2; x.shadowColor = a; x.shadowBlur = 14; x.stroke(); x.shadowBlur = 0;
      if (ph > 0 && ph < 1) { x.fillStyle = a; x.beginPath(); x.arc(ph * w, cy, 3, 0, 7); x.fill(); }
      if (reduced) cancelAnimationFrame(raf);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvas} aria-hidden="true" />;
}

export function EmptyState({ lastChip, onRemoveLast, onReset }: { lastChip?: string; onRemoveLast: () => void; onReset: () => void }) {
  return (
    <div className={s.empty}>
      <div className={s.flatScreen}>
        <Flatline />
        <span>SIGNAL · 0 RESULTS</span>
      </div>
      <div className={s.emptyTitle}>No plugins match these filters</div>
      <p>That combination flatlined. Loosen one filter and the signal should come back.</p>
      <div className={s.emptyActions}>
        {lastChip && <button type="button" data-magnetic="" className="btn-ghost" onClick={onRemoveLast}>Remove “{lastChip}”</button>}
        <button type="button" data-magnetic="" className="btn-acc" onClick={onReset}>Reset all filters</button>
      </div>
    </div>
  );
}
