// Compact wire format for /catalog-index.json: shared lookup tables plus one
// positional row per product, instead of an object with repeated keys each.
import type { Item } from "./data/types";

type Row = [
  n: string, p: string, dev: number, t: 0 | 1, cat: number, s: string, r: string | 0,
  f: number, o: number, im: string | 0, iw: number, ih: number,
  rt: number | 0, rc: number, flags: number,
];

export interface PackedIndex {
  v: 1;
  devs: [string, string][];
  cats: [string, string][];
  formats: string[];
  os: string[];
  rows: Row[];
}

const table = <T,>(xs: T[], key: (x: T) => string) => {
  const list: T[] = [], at = new Map<string, number>();
  for (const x of xs) { const k = key(x); if (!at.has(k)) { at.set(k, list.length); list.push(x); } }
  return { list, at: (x: T) => at.get(key(x))! };
};
const mask = (vals: string[], list: string[]) => vals.reduce((m, v) => m | (1 << list.indexOf(v)), 0);
const unmask = (m: number, list: string[]) => list.filter((_, i) => m & (1 << i));

export function packIndex(items: Item[]): PackedIndex {
  const devs = table(items.map((i) => [i.d, i.dp] as [string, string]), (x) => x[1]);
  const cats = table(items.map((i) => [i.cp, i.c] as [string, string]), (x) => x[0]);
  const formats = [...new Set(items.flatMap((i) => i.f))];
  const os = [...new Set(items.flatMap((i) => i.o))];
  return {
    v: 1, devs: devs.list, cats: cats.list, formats, os,
    rows: items.map((i) => [
      i.n, i.p, devs.at([i.d, i.dp]), i.t === "preset" ? 1 : 0, cats.at([i.cp, i.c]), i.s, i.r ?? 0,
      mask(i.f, formats), mask(i.o, os), i.im ?? 0, i.iw, i.ih,
      i.rt ?? 0, i.rc, i.tr ? 1 : 0,
    ]),
  };
}

export function unpackIndex(x: PackedIndex): Item[] {
  return x.rows.map(([n, p, dev, t, cat, s, r, f, o, im, iw, ih, rt, rc, flags]) => ({
    n, p, d: x.devs[dev][0], dp: x.devs[dev][1], t: t ? "preset" : "plugin", c: x.cats[cat][1], cp: x.cats[cat][0], s,
    r: r || null, f: unmask(f, x.formats), o: unmask(o, x.os),
    im: im || null, iw, ih, rt: rt || null, rc, tr: !!(flags & 1),
  }));
}
