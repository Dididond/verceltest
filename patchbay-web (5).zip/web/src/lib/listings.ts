import "server-only";
import {
  type Facet, getByCategory, getByDeveloper, getByRequires, getByType, getCategories, getCategory, getDeveloper, getDevelopers,
  getRequires, getRequiresList,
} from "./data/catalog";
import type { Item, ProductType } from "./data/types";
import { pluralize } from "./format";
import { PAGE_SIZE } from "./filters";

export interface Listing {
  path: string;
  eyebrow: string;
  h1: string;
  title: string;
  description: string;
  intro: string;
  items: Item[];
  crumbs: { name: string; path: string }[];
  /** Sibling listings for internal linking. */
  more?: { heading: string; links: Facet[] };
}

/**
 * Listings with fewer products than this are near-duplicates of the product
 * page itself: they stay crawlable (noindex,follow) but are kept out of the
 * index and the sitemap.
 */
export const MIN_INDEXABLE_ITEMS = 3;
export const isThin = (l: Listing) => l.items.length < MIN_INDEXABLE_ITEMS;

export const pageCount = (l: Listing) => Math.max(1, Math.ceil(l.items.length / PAGE_SIZE));
export const pageItems = (l: Listing, page: number) => l.items.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
/** Static params for /…/page/[n] (page 1 lives at the base path). */
export const extraPages = (l: Listing) => Array.from({ length: pageCount(l) - 1 }, (_, i) => String(i + 2));

const noun = (t: ProductType, n: number) => (t === "plugin" ? pluralize(n, "plugin") : pluralize(n, "preset pack"));
const names = (items: Item[], k = 3) => {
  const top = [...new Set(items.map((i) => i.n))].slice(0, k);
  return top.length > 1 ? top.slice(0, -1).join(", ") + " and " + top[top.length - 1] : top[0] ?? "";
};
const devCount = (items: Item[]) => new Set(items.map((i) => i.d)).size;
const home = { name: "Home", path: "/" };

export function typeListing(t: ProductType): Listing {
  const items = getByType(t);
  const plugin = t === "plugin";
  const path = plugin ? "/plugins" : "/presets";
  return {
    path,
    eyebrow: plugin ? "All plugins" : "All presets",
    h1: plugin ? "Plugins" : "Presets",
    title: plugin ? "Audio Plugins: Synths, Effects & Kontakt Instruments" : "Synth Presets & Expansion Packs",
    description: plugin
      ? `Explore ${noun(t, items.length)} from ${devCount(items)} developers: synths, effects, mixing tools and Kontakt instruments, with formats, OS support and ratings.`
      : `Explore ${noun(t, items.length)} for Serum, Kontakt, Massive and ${getRequiresList().length - 3} more synths and samplers, with the exact host each pack needs.`,
    intro: plugin
      ? `${items.length.toLocaleString("en-US")} plugins from ${devCount(items)} developers, sorted by how many producers have rated them. Every card lists formats, operating systems and its Plugin Boutique rating.`
      : `${items.length.toLocaleString("en-US")} preset packs and expansions. Each one lists the synth or sampler it needs, so you only see sounds you can actually load.`,
    items,
    crumbs: [home, { name: plugin ? "Plugins" : "Presets", path }],
    more: { heading: "Categories", links: getCategories().filter((c) => c.type === t) },
  };
}

export function categoryListing(t: ProductType, slug: string): Listing | null {
  const path = `/${t}s/category/${slug}`;
  const cat = getCategory(path);
  if (!cat) return null;
  const items = getByCategory(path);
  const n = noun(t, items.length);
  return {
    path,
    eyebrow: t === "plugin" ? "Plugin category" : "Preset category",
    h1: cat.name,
    title: `${cat.name}: ${n} compared`,
    description: `Explore ${n} in ${cat.name} from ${pluralize(cat.developers, "developer")}. Compare formats, OS support and ratings.`,
    intro: `${n} in ${cat.name} from ${pluralize(cat.developers, "developer")}. The most-rated picks are ${names(items)}.`,
    items,
    crumbs: [home, { name: t === "plugin" ? "Plugins" : "Presets", path: `/${t}s` }, { name: cat.name, path }],
    more: { heading: "Other categories", links: getCategories().filter((c) => c.type === t && c.path !== path) },
  };
}

export function developerListing(slug: string): Listing | null {
  const path = `/developers/${slug}`;
  const dev = getDeveloper(path);
  if (!dev) return null;
  const items = getByDeveloper(path);
  const plugins = items.filter((i) => i.t === "plugin").length, presets = items.length - plugins;
  const what = [plugins && noun("plugin", plugins), presets && noun("preset", presets)].filter(Boolean).join(" and ");
  const cats = [...new Set(items.map((i) => i.c))];
  return {
    path,
    eyebrow: "Developer",
    h1: dev.name,
    title: `${dev.name}: ${what}`,
    description: `All ${what} by ${dev.name}. Compare formats, OS support and ratings.`,
    intro: `${what[0].toUpperCase() + what.slice(1)} by ${dev.name} across ${pluralize(cats.length, "category", "categories")}, including ${cats.slice(0, 3).join(", ")}. Most rated: ${names(items)}.`,
    items,
    crumbs: [home, { name: "Developers", path: "/developers" }, { name: dev.name, path }],
  };
}

export function requiresListing(slug: string): Listing | null {
  const req = getRequires(slug);
  if (!req) return null;
  const items = getByRequires(slug);
  return {
    path: req.path,
    eyebrow: "Presets by synth",
    h1: `Presets for ${req.name}`,
    title: `${req.name} Presets: ${noun("preset", items.length)}`,
    description: `${noun("preset", items.length)} that load in ${req.name}, from ${pluralize(req.developers, "sound designer")}. Compare packs, formats and ratings.`,
    intro: `Every pack on this page needs ${req.name} to load; the synth itself is sold separately. ${pluralize(req.developers, "sound designer")} so far, including ${[...new Set(items.map((i) => i.d))].slice(0, 3).join(", ")}.`,
    items,
    crumbs: [home, { name: "Presets", path: "/presets" }, { name: `For ${req.name}`, path: req.path }],
    more: { heading: "Presets for other synths", links: getRequiresList().filter((r) => r.path !== req.path) },
  };
}

export { getCategories, getDevelopers, getRequiresList };
