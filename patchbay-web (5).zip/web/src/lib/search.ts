import "server-only";
import { getItems } from "./data/catalog";
import type { Item } from "./data/types";

export interface Hit { key: string; name: string; meta: string; right: string; href: string }
export interface SearchResult { groups: { label: string; count: number; items: Hit[] }[]; noResults: boolean; label: string }

const STOP = new Set(["for", "the", "a", "an", "with", "under", "and", "of", "in"]);

/** Grouped quick search for the hero box; runs on the server so pages don't ship the catalog. */
export function quickSearch(raw: string): SearchResult {
  const toks = raw.trim().toLowerCase().split(/\s+/).filter((t) => t && !STOP.has(t)).map((t) => t.replace(/s$/, "")).slice(0, 8);
  const all = getItems();
  const hit = (str: string) => toks.every((t) => str.toLowerCase().includes(t));
  const P = toks.length ? all.filter((p) => hit([p.n, p.d, p.c, p.s, p.t, p.r ?? ""].join(" "))) : all;
  const mk = (p: Item): Hit => ({
    key: p.p, name: p.n, href: p.p, right: p.rt != null && p.rc > 0 ? `★ ${p.rt.toFixed(1)}` : "→",
    meta: [p.d, p.c, [p.r, ...p.f].filter(Boolean).slice(0, 3).join(" ")].filter(Boolean).join("  ·  "),
  });
  const plugins = P.filter((p) => p.t === "plugin"), presets = P.filter((p) => p.t === "preset");
  const devMap = new Map<string, { name: string; path: string; n: number }>();
  if (toks.length) for (const p of all) if (hit(p.d)) { const d = devMap.get(p.dp) ?? { name: p.d, path: p.dp, n: 0 }; d.n++; devMap.set(p.dp, d); }
  const devs = [...devMap.values()].sort((a, b) => b.n - a.n);
  const groups: SearchResult["groups"] = [];
  if (plugins.length) groups.push({ label: toks.length ? "Plugins" : "Popular plugins", count: plugins.length, items: plugins.slice(0, 4).map(mk) });
  if (presets.length) groups.push({ label: toks.length ? "Preset packs" : "Popular preset packs", count: presets.length, items: presets.slice(0, 3).map(mk) });
  if (devs.length) groups.push({ label: "Developers", count: devs.length, items: devs.slice(0, 3).map((d) => ({ key: d.path, name: d.name, meta: `${d.n} products`, right: "→", href: d.path })) });
  const total = plugins.length + presets.length + devs.length;
  return { groups, noResults: !!toks.length && total === 0, label: toks.length ? `${total.toLocaleString("en-US")} results` : "Most rated right now" };
}
