"use client";

import { useLayoutEffect, useRef } from "react";
import { EASE } from "./site";

/** Captures positions before a state change and animates items from there (FLIP). */
export function useFlip(container: React.RefObject<HTMLElement | null>, dep: unknown) {
  const rects = useRef<Map<string, DOMRect> | null>(null);
  const capture = () => {
    const map = new Map<string, DOMRect>();
    container.current?.querySelectorAll<HTMLElement>("[data-flip]").forEach((el) => map.set(el.dataset.flip!, el.getBoundingClientRect()));
    rects.current = map;
  };
  useLayoutEffect(() => {
    const before = rects.current;
    rects.current = null;
    if (!before || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let k = 0;
    container.current?.querySelectorAll<HTMLElement>("[data-flip]").forEach((el) => {
      const a = before.get(el.dataset.flip!), b = el.getBoundingClientRect();
      if (a) {
        const dx = a.left - b.left, dy = a.top - b.top;
        if (Math.abs(dx) + Math.abs(dy) > 1) el.animate([{ transform: `translate(${dx}px,${dy}px)` }, { transform: "none" }], { duration: 680, easing: EASE.spring });
      } else if (b.top < innerHeight) {
        el.animate([{ opacity: 0, transform: "scale(.92) translateY(18px)" }, { opacity: 1, transform: "none" }], { duration: 580, delay: k++ * 38, easing: EASE.spring, fill: "backwards" });
      }
    });
  }, [dep, container]);
  return capture;
}
