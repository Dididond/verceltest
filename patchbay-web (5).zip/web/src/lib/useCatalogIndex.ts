"use client";

import { useEffect, useState } from "react";
import type { Item } from "./data/types";
import { type PackedIndex, unpackIndex } from "./indexCodec";

let pending: Promise<Item[]> | null = null;

/** Fetches the slim catalog index once per page load. Only /browse uses it. */
export function loadCatalogIndex() {
  return (pending ??= fetch("/catalog-index.json").then((r) => {
    if (!r.ok) throw new Error("catalog index " + r.status);
    return (r.json() as Promise<PackedIndex>).then(unpackIndex);
  }).catch((e) => { pending = null; throw e; }));
}

export function useCatalogIndex(enabled = true) {
  const [items, setItems] = useState<Item[] | null>(null);
  useEffect(() => {
    if (!enabled) return;
    let live = true;
    loadCatalogIndex().then((i) => live && setItems(i), () => {});
    return () => { live = false; };
  }, [enabled]);
  return items;
}
