import { pageZoom } from "./site";

// Small deterministic noise + waveform helpers shared by every canvas motif.

export const hash = (i: number) => {
  const v = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return v - Math.floor(v);
};

export const vnoise = (x: number) => {
  const i = Math.floor(x), f = x - i, s = f * f * (3 - 2 * f);
  return hash(i) + (hash(i + 1) - hash(i)) * s;
};

/** Sine → saw (shape 0..1) → noise (1..2). */
export function wave(u: number, shape: number, ph: number, t: number, f: number) {
  const th = 2 * Math.PI * u * f + ph, sn = Math.sin(th);
  if (shape < 0.002) return sn;
  let saw = 0;
  for (let k = 1; k <= 12; k++) saw += ((k % 2 ? 1 : -1) * Math.sin(k * th)) / k;
  saw *= 0.62;
  if (shape <= 1) return sn + (saw - sn) * shape;
  const nz = (vnoise(u * f * 9 + t * 0.0018) * 2 - 1) * 0.85 + (vnoise(u * f * 33 - t * 0.004) * 2 - 1) * 0.3;
  return saw + (nz - saw) * (shape - 1);
}

export interface Fitted {
  ctx: CanvasRenderingContext2D;
  w: number;
  h: number;
}

/** Sizes the backing store to the element at up to 2× DPR. */
export function fitCanvas(c: HTMLCanvasElement): Fitted | null {
  const w = c.clientWidth, h = c.clientHeight;
  if (!w || !h) return null;
  const d = Math.min(2.5, (window.devicePixelRatio || 1) * pageZoom());
  if (c.width !== Math.round(w * d) || c.height !== Math.round(h * d)) {
    c.width = Math.round(w * d);
    c.height = Math.round(h * d);
  }
  const ctx = c.getContext("2d")!;
  ctx.setTransform(d, 0, 0, d, 0, 0);
  return { ctx, w, h };
}

export function cssVar(name: string, el: Element = document.documentElement) {
  return getComputedStyle(el).getPropertyValue(name).trim();
}

export function drawScopeGrid({ ctx, w, h }: Fitted) {
  ctx.strokeStyle = "oklch(1 0 0 / 0.07)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 1; i < 10; i++) { ctx.moveTo((w * i) / 10, 0); ctx.lineTo((w * i) / 10, h); }
  for (let j = 1; j < 6; j++) { ctx.moveTo(0, (h * j) / 6); ctx.lineTo(w, (h * j) / 6); }
  ctx.stroke();
}

/** Three-trace phosphor oscilloscope line. */
export function drawOsc(f: Fitted, acc: string, o: { shape: number; amp: number; cy: number; freq: number; ph: number; t: number }) {
  const { ctx, w, h } = f;
  const cy = h * o.cy, A = o.amp * h;
  ([[0.6, 0.1, 1], [0.3, 0.25, 1.2], [0, 1, 2.2]] as const).forEach(([lag, al, lw], L) => {
    ctx.beginPath();
    for (let px = 0; px <= w; px += 2) {
      const u = px / w, edge = Math.min(1, u * 7, (1 - u) * 7);
      const y = cy - wave(u, o.shape, o.ph - lag, o.t - lag * 300, o.freq) * A * edge;
      px ? ctx.lineTo(px, y) : ctx.moveTo(px, y);
    }
    ctx.globalAlpha = al; ctx.strokeStyle = acc; ctx.lineWidth = lw; ctx.lineJoin = "round";
    ctx.shadowColor = acc; ctx.shadowBlur = L === 2 ? 16 : 0;
    ctx.stroke();
  });
  ctx.globalAlpha = 1; ctx.shadowBlur = 0;
}

export interface SpecState { lv: Float32Array; pk: Float32Array }

/**
 * Spectrum analyser bars with falling peak caps. Returns the normalised
 * position (0..1) of the loudest band so callers can show a readout.
 */
export function drawSpectrum(
  f: Fitted, st: { current: SpecState | null }, colors: { acc: string; ink: string },
  o: { t: number; bandWidth: number; hmax: number; energy: number; mx: number | null; my: number },
) {
  const { ctx, w, h } = f;
  const N = Math.max(24, Math.min(96, Math.floor(w / o.bandWidth)));
  if (!st.current || st.current.lv.length !== N) st.current = { lv: new Float32Array(N), pk: new Float32Array(N) };
  const { lv, pk } = st.current;
  const bw = w / N, gap = Math.max(2, bw * 0.28);
  ctx.clearRect(0, 0, w, h);
  const g = ctx.createLinearGradient(0, h, 0, h * (1 - o.hmax));
  g.addColorStop(0, colors.acc.replace(")", " / 0.95)"));
  g.addColorStop(1, colors.acc.replace(")", " / 0.08)"));
  let peakI = 0;
  for (let i = 0; i < N; i++) {
    const u = i / (N - 1);
    let tg = (vnoise(i * 0.2 + o.t * 0.0011) * 0.6 + 0.12) * (1 - u * 0.45) * o.energy + vnoise(i * 1.7 + o.t * 0.006) * 0.1 * o.energy;
    if (o.mx != null) tg += 0.75 * Math.exp(-((u - o.mx) ** 2) / 0.006) * (1.1 - o.my * 0.6);
    tg = Math.min(1, tg);
    lv[i] += (tg - lv[i]) * (tg > lv[i] ? 0.35 : 0.07);
    pk[i] = Math.max(pk[i] - 0.003, lv[i]);
    if (lv[i] > lv[peakI]) peakI = i;
    const bh = lv[i] * h * o.hmax;
    ctx.fillStyle = g;
    ctx.fillRect(i * bw + gap / 2, h - bh, bw - gap, bh);
    ctx.fillStyle = colors.ink; ctx.globalAlpha = 0.7;
    ctx.fillRect(i * bw + gap / 2, h - pk[i] * h * o.hmax - 4, bw - gap, 2);
    ctx.globalAlpha = 1;
  }
  return peakI / (N - 1);
}

export const hzLabel = (pos: number) => {
  const hz = 20 * Math.pow(1000, pos);
  return hz > 1000 ? (hz / 1000).toFixed(1) + " kHz" : Math.round(hz) + " Hz";
};

export type Motif = "saw" | "grain" | "decay" | "ping" | "knee" | "eq" | "clip" | "limit" | "util" | "dots";

/** Category tile line art; `ph` animates it while the tile is hovered. */
export function drawMotif(f: Fitted, motif: Motif, ph: number, color: string) {
  const { ctx: x, w, h } = f, cy = h / 2;
  x.clearRect(0, 0, w, h);
  x.strokeStyle = color; x.fillStyle = color; x.lineWidth = 1.5; x.lineJoin = "round";
  const path = (fn: (u: number) => number) => {
    x.beginPath();
    for (let px = 0; px <= w; px += 2) { const u = px / w, y = cy - fn(u) * (h * 0.42); px ? x.lineTo(px, y) : x.moveTo(px, y); }
    x.stroke();
  };
  const knee = (a: number) => (a < 0.45 ? a : a < 0.6 ? 0.45 + (a - 0.45) * 0.6 : 0.54 + (a - 0.6) * 0.3);
  switch (motif) {
    case "saw": path((u) => ((u * 3 + ph * 0.5) % 1) * 2 - 1); break;
    case "decay": path((u) => Math.exp(-3.2 * u) * Math.sin(2 * Math.PI * (9 * u) - ph * 4)); break;
    case "clip": path((u) => Math.tanh(3.5 * Math.sin(2 * Math.PI * 2 * u + ph * 2)) / Math.tanh(3.5)); break;
    case "limit": path((u) => Math.max(-0.55, Math.min(0.55, Math.sin(2 * Math.PI * 6 * u + ph * 3) * (0.4 + vnoise(u * 8 + ph) * 1.2)))); break;
    case "eq": path((u) => 0.7 * Math.exp(-((u - 0.22) ** 2) / 0.008) - 0.6 * Math.exp(-((u - 0.58 - 0.06 * Math.sin(ph * 2)) ** 2) / 0.004) + 0.35 * Math.exp(-((u - 0.86) ** 2) / 0.02)); break;
    case "ping": {
      for (let k = 0; k < 9; k++) {
        const hh = h * 0.44 * Math.pow(0.74, k) * (1 + 0.15 * Math.sin(ph * 3 - k)), px = w * (0.06 + k * 0.105);
        x.fillRect(px, k % 2 ? cy : cy - hh, 3, hh);
      }
      x.globalAlpha = 0.3; x.fillRect(0, cy, w, 1); x.globalAlpha = 1;
      break;
    }
    case "knee": {
      const m = h * 0.06, s = h - 2 * m, ox = (w - s) / 2;
      x.globalAlpha = 0.3; x.strokeRect(ox, m, s, s); x.globalAlpha = 1;
      x.beginPath();
      for (let i = 0; i <= 60; i++) { const a = i / 60, y = m + s - knee(a) * s; i ? x.lineTo(ox + a * s, y) : x.moveTo(ox, y); }
      x.stroke();
      const a = (ph * 0.3) % 1;
      x.beginPath(); x.arc(ox + a * s, m + s - knee(a) * s, 3, 0, 7); x.fill();
      break;
    }
    case "util": {
      for (let k = 0; k < 28; k++) {
        const lv = 0.3 + vnoise(k * 0.4 + ph * 2) * 0.7;
        x.globalAlpha = k / 28 < lv ? 1 : 0.22;
        x.fillRect(k * (w / 28), cy - 10, w / 28 - 3, 8);
        x.fillRect(k * (w / 28), cy + 4, w / 28 - 3, 8);
      }
      x.globalAlpha = 1;
      break;
    }
    case "grain": {
      for (let k = 0; k < 46; k++) {
        const u = hash(k * 3.1), v = hash(k * 7.7 + 1), r = 1 + hash(k) * 2.5 * (1 + 0.5 * Math.sin(ph * 3 + k));
        x.globalAlpha = 0.4 + 0.6 * hash(k * 1.3);
        x.beginPath(); x.arc(u * w, (v * 0.8 + 0.1) * h, r, 0, 7); x.fill();
      }
      x.globalAlpha = 1;
      break;
    }
    case "dots": {
      const cols = 16, rows = 4, gx = w / cols, gy = h / rows;
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        x.globalAlpha = hash(i * 13 + j * 7 + Math.floor(ph * 2)) > 0.62 ? 1 : 0.2;
        x.fillRect(i * gx + 1, j * gy + gy * 0.25, gx - 4, gy * 0.5);
      }
      x.globalAlpha = 1;
      break;
    }
  }
}
