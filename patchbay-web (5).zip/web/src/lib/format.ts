// Client-safe display helpers for catalog items.
import type { Item } from "./data/types";

const STORE_IMG = "https://banners.pluginboutique.com/";

/** Where mirrored WebP copies live: a bucket/CDN origin, or /product-images when served from public/. */
export const IMAGE_BASE = (process.env.NEXT_PUBLIC_IMAGE_BASE || "/product-images").replace(/\/$/, "");
export const CARD_W = 480;

/** The store's image id, which is also our file name. */
export const imageId = (url: string | null) => (url && url.startsWith(STORE_IMG) ? url.slice(STORE_IMG.length).split(/[/?#]/)[0] || null : null);
export const cardImage = (id: string) => `${IMAGE_BASE}/${id}-${CARD_W}.webp`;
export const fullImage = (id: string) => `${IMAGE_BASE}/${id}.webp`;

export const monogram = (name: string) => name.replace(/[^\p{L}\p{N} ]/gu, "").split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();

export const slugify = (s: string) =>
  s.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export const requiresPath = (r: string) => `/presets/for/${slugify(r)}`;

export const typeLabel = (t: Item["t"]) => (t === "preset" ? "Preset pack" : "Plugin");

export const ratingText = (rating: number, count: number) =>
  `Rated ${rating.toFixed(1)}/5 on Plugin Boutique (${count.toLocaleString("en-US")} rating${count === 1 ? "" : "s"})`;

export const pluralize = (n: number, one: string, many = one + "s") => `${n.toLocaleString("en-US")} ${n === 1 ? one : many}`;
