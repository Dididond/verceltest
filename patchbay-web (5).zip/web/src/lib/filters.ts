// Catalog filtering over slim items. Pure, so it runs on the server (first
// page of /browse) and in the browser (after the index is fetched).
import type { Item, ProductType } from "./data/types";

export const PAGE_SIZE = 24;
export const SORTS = ["Relevance", "Highest rated", "Most rated", "Name A–Z"] as const;
export type Sort = (typeof SORTS)[number];
export const FORMATS = ["VST3", "VST2", "AU", "AAX", "CLAP", "Standalone", "Kontakt", "RTAS", "Reaktor", "LV2"];
export const OSES = ["Windows", "macOS", "Linux", "iOS"];

export interface Filters {
  type: "all" | ProductType;
  cats: string[];
  trial: boolean;
  formats: string[];
  os: string[];
  requires: string;
  rating: number;
  q: string;
}

export const DEFAULT_FILTERS: Filters = { type: "all", cats: [], trial: false, formats: [], os: [], requires: "", rating: 0, q: "" };

export type Facet = "type" | "cats" | "trial" | "requires";

/** `skip` ignores one facet so that facet's own option counts stay meaningful. */
export function matches(i: Item, f: Filters, skip?: Facet) {
  if (skip !== "type" && f.type !== "all" && i.t !== f.type) return false;
  if (skip !== "cats" && f.cats.length && !f.cats.includes(i.cp)) return false;
  if (skip !== "trial" && f.trial && !i.tr) return false;
  if (f.formats.length && !f.formats.every((x) => i.f.includes(x))) return false;
  if (f.os.length && !f.os.every((o) => i.o.includes(o))) return false;
  if (skip !== "requires" && f.requires && i.r !== f.requires) return false;
  if (f.rating && !(i.rt != null && i.rt >= f.rating)) return false;
  if (f.q) {
    const hay = (i.n + " " + i.d + " " + i.c + " " + i.s + " " + (i.r ?? "")).toLowerCase();
    if (!f.q.toLowerCase().split(/\s+/).filter(Boolean).every((w) => hay.includes(w))) return false;
  }
  return true;
}

const SORTERS: Partial<Record<Sort, (a: Item, b: Item) => number>> = {
  "Highest rated": (a, b) => (b.rc >= 10 ? b.rt ?? 0 : 0) - (a.rc >= 10 ? a.rt ?? 0 : 0) || b.rc - a.rc,
  "Most rated": (a, b) => b.rc - a.rc,
  "Name A–Z": (a, b) => a.n.localeCompare(b.n),
};

/** Items are expected pre-sorted by popularity (Relevance). */
export function results(items: Item[], f: Filters, sort: Sort) {
  const r = items.filter((i) => matches(i, f));
  const by = SORTERS[sort];
  return by ? r.sort(by) : r;
}

export interface Chip { key: string; label: string; undo: Partial<Filters> }

export function activeChips(f: Filters, catLabel: (p: string) => string): Chip[] {
  const c: Chip[] = [];
  if (f.type !== "all") c.push({ key: "type", label: f.type === "plugin" ? "Plugins" : "Presets", undo: { type: "all" } });
  f.cats.forEach((x) => c.push({ key: "c" + x, label: catLabel(x), undo: { cats: f.cats.filter((y) => y !== x) } }));
  if (f.requires) c.push({ key: "req", label: "For " + f.requires, undo: { requires: "" } });
  if (f.trial) c.push({ key: "trial", label: "Free trial", undo: { trial: false } });
  f.formats.forEach((x) => c.push({ key: "f" + x, label: x, undo: { formats: f.formats.filter((y) => y !== x) } }));
  f.os.forEach((x) => c.push({ key: "o" + x, label: x, undo: { os: f.os.filter((y) => y !== x) } }));
  if (f.rating) c.push({ key: "rating", label: f.rating.toFixed(1) + "+ rating", undo: { rating: 0 } });
  if (f.q) c.push({ key: "q", label: "“" + f.q + "”", undo: { q: "" } });
  return c;
}

// ---------- URL <-> filters ----------

type Params = Record<string, string | string[] | undefined>;

export function filtersFromParams(sp: Params): { filters: Filters; sort: Sort } {
  const all = (k: string) => ([] as string[]).concat(sp[k] ?? []);
  const one = (k: string) => all(k)[0];
  const type = one("type");
  const sort = one("sort");
  return {
    filters: {
      type: type === "plugin" || type === "preset" ? type : "all",
      cats: all("cat"),
      trial: one("trial") === "1",
      formats: all("format").filter((x) => FORMATS.includes(x)),
      os: all("os").filter((x) => OSES.includes(x)),
      requires: one("requires") ?? "",
      rating: Math.max(0, Math.min(5, +(one("rating") ?? 0) || 0)),
      q: one("q") ?? "",
    },
    sort: (SORTS as readonly string[]).includes(sort ?? "") ? (sort as Sort) : "Relevance",
  };
}

export function filtersToQuery(f: Filters, sort: Sort) {
  const q = new URLSearchParams();
  if (f.type !== "all") q.set("type", f.type);
  f.cats.forEach((c) => q.append("cat", c));
  if (f.requires) q.set("requires", f.requires);
  if (f.trial) q.set("trial", "1");
  f.formats.forEach((x) => q.append("format", x));
  f.os.forEach((x) => q.append("os", x));
  if (f.rating) q.set("rating", String(f.rating));
  if (f.q) q.set("q", f.q);
  if (sort !== "Relevance") q.set("sort", sort);
  return q.toString();
}
