import "server-only";
import { existsSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { gunzipSync } from "node:zlib";
import { slugify } from "../format";
import { buildItems, byPopularity } from "../../../scripts/items.mjs";
import { imageManifest } from "./images";
import type { Card, Item, ProductType } from "./types";

/**
 * The full catalog lives in data/catalog_seo.json.gz and is only ever read
 * here, on the server. It is decompressed and parsed once per process (each
 * build worker, or the production server) and then served from memory.
 */
const FILE = path.join(process.cwd(), "data", "catalog_seo.json.gz");
/** Slim items, written by the prebuild step (scripts/build-items.mjs) and shipped with the server. */
const ITEMS_CACHE = path.join(process.cwd(), "data", "items.cache.json");

interface CardStore { cards: Card[]; byPath: Map<string, Card> }
/** items: listable (indexable) cards by popularity; extra: noindex cards, for related links. */
interface ItemStore { items: Item[]; byPath: Map<string, Item> }

const g = globalThis as typeof globalThis & { __pbCards?: CardStore; __pbItems?: ItemStore };

export { byPopularity };

function loadCards(): CardStore {
  if (g.__pbCards) return g.__pbCards;
  const cards = JSON.parse(gunzipSync(readFileSync(FILE)).toString("utf8")) as Card[];
  return (g.__pbCards = { cards, byPath: new Map(cards.map((c) => [c.path, c])) });
}

/** The cache is only trusted if it's newer than the catalog and the image manifest. */
function cacheFresh() {
  if (!existsSync(ITEMS_CACHE)) return false;
  const t = statSync(ITEMS_CACHE).mtimeMs;
  const manifest = path.join(process.cwd(), "data", "images.json");
  return t >= statSync(FILE).mtimeMs && (!existsSync(manifest) || t >= statSync(manifest).mtimeMs);
}

/**
 * Listable items. A cold start reads the ~2 MB cache instead of parsing the
 * full catalog; without a fresh cache the same items are built in memory.
 */
function loadItems(): ItemStore {
  if (g.__pbItems) return g.__pbItems;
  const { items, extra } = (cacheFresh()
    ? JSON.parse(readFileSync(ITEMS_CACHE, "utf8"))
    : buildItems(loadCards().cards, imageManifest())) as { items: Item[]; extra: Item[] };
  return (g.__pbItems = { items, byPath: new Map([...items, ...extra].map((i) => [i.p, i])) });
}

// ---------- Cards (full data, product pages only) ----------

export const getAllCards = () => loadCards().cards;
export const getCardByPath = (p: string) => loadCards().byPath.get(p);
/** Slugs for every product page of a type, indexable or not. */
export const getAllSlugs = (type: ProductType) => loadCards().cards.filter((c) => c.product.product_type === type).map((c) => c.slug);

// ---------- Slim items (listings, search, cards) ----------

export const getItems = () => loadItems().items;
/** Looks up any card's slim item, including noindex variants (for related links). */
export const getItem = (p: string) => loadItems().byPath.get(p);
export const getItemsByPaths = (paths: string[]) => paths.map(getItem).filter((i): i is Item => !!i);
export const getByType = (t: ProductType) => getItems().filter((i) => i.t === t);
export const getByCategory = (catPath: string) => getItems().filter((i) => i.cp === catPath);
export const getByDeveloper = (devPath: string) => getItems().filter((i) => i.dp === devPath);
export const getByRequires = (slug: string) => getItems().filter((i) => i.t === "preset" && i.r && slugify(i.r) === slug);

// ---------- Facets ----------

export interface Facet { name: string; path: string; type?: ProductType; count: number; developers: number }

function facets(key: (i: Item) => [string, string, ProductType?] | null): Facet[] {
  const m = new Map<string, Facet & { devs: Set<string> }>();
  for (const i of getItems()) {
    const k = key(i);
    if (!k) continue;
    const [path, name, type] = k;
    let f = m.get(path);
    if (!f) m.set(path, (f = { name, path, type, count: 0, developers: 0, devs: new Set() }));
    f.count++;
    f.devs.add(i.d);
  }
  return [...m.values()].map(({ devs, ...f }) => ({ ...f, developers: devs.size })).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

let cache: { cats?: Facet[]; devs?: Facet[]; reqs?: Facet[] } = {};
export const getCategories = () => (cache.cats ??= facets((i) => [i.cp, i.c, i.t]));
export const getDevelopers = () => (cache.devs ??= facets((i) => [i.dp, i.d]));
export const getRequiresList = () => (cache.reqs ??= facets((i) => (i.t === "preset" && i.r ? [`/presets/for/${slugify(i.r)}`, i.r] : null)));

export const getCategory = (p: string) => getCategories().find((c) => c.path === p);
export const getDeveloper = (p: string) => getDevelopers().find((d) => d.path === p);
/** True when a category, developer or presets-for listing page exists at this path. */
export const hasListing = (p: string) => !!(getCategory(p) || getDeveloper(p) || getRequiresList().some((r) => r.path === p));

export const getRequires = (slug: string) => getRequiresList().find((r) => r.path === `/presets/for/${slug}`);

export function getStats() {
  const items = getItems();
  return {
    plugins: items.filter((i) => i.t === "plugin").length,
    presets: items.filter((i) => i.t === "preset").length,
    developers: getDevelopers().length,
    categories: getCategories().length,
    synths: getRequiresList().length,
    formats: [...new Set(items.flatMap((i) => i.f))],
  };
}
