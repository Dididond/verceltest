// Shapes of data/catalog_seo.json. Type-only, so safe to import anywhere.

export type ProductType = "plugin" | "preset";

export interface Link { name: string; path: string; url?: string; developer?: string }

export interface Card {
  id: string;
  slug: string;
  path: string;
  url: string;
  status: "done" | "flagged";
  indexable: boolean;
  product: {
    name: string;
    developer: string;
    product_type: ProductType;
    subcategory: string;
    requires: string | null;
    price: number;
    sale_price: number | null;
    currency: string;
    is_free: boolean;
    formats: string[];
    os: string[];
    bits: string | null;
    has_trial: boolean;
    image_url: string | null;
    rating: number | null;
    rating_count: number | null;
  };
  store: { name: string; url: string; rating: number | null; rating_count: number | null };
  category: { label: string; path: string };
  developer: { name: string; path: string };
  meta: Record<string, string>;
  breadcrumbs: { name: string; url: string }[];
  specs: { label: string; value: string }[];
  content: {
    h1: string;
    summary: string;
    intro: string;
    sections: { heading: string; body: string }[];
    key_features: string[];
    use_cases: string[];
    faq: { question: string; answer: string }[];
    image_alt: string;
  } | null;
  related: Link[];
  more_from_developer: Link[];
  upgrade_options: { name: string; price: number; currency: string; store_url: string; path?: string }[];
  canonical_product?: { name: string; path: string; url: string };
  json_ld: Record<string, unknown>[];
}

/**
 * Slim listing record for cards, filters and search. Short keys keep the
 * client-side index small (served from /catalog-index.json).
 */
export interface Item {
  /** name */ n: string;
  /** path */ p: string;
  /** developer */ d: string;
  /** developer path */ dp: string;
  /** type */ t: ProductType;
  /** category label */ c: string;
  /** category path */ cp: string;
  /** subcategory */ s: string;
  /** requires (host synth/sampler) */ r: string | null;
  /** formats */ f: string[];
  /** os */ o: string[];
  /** mirrored image id (null when not mirrored yet) */ im: string | null;
  /** mirrored image width / height (full-size copy) */ iw: number;
  ih: number;
  /** store rating */ rt: number | null;
  /** store rating count */ rc: number;
  /** has trial */ tr: boolean;
}
