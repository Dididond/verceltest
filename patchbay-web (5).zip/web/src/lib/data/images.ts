import "server-only";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { IMAGE_BASE, imageId } from "../format";
import { SITE_URL } from "../site";

/**
 * Mirrored product images (see scripts/mirror-images.mjs). data/images.json maps
 * the store's image id to the [width, height] of our 1200px-max WebP copy.
 * Products without an entry render a placeholder; we never hotlink the store.
 */
type Entry = [number, number, number?, number?];
const FILE = path.join(process.cwd(), "data", "images.json");
const g = globalThis as typeof globalThis & { __pbImages?: Record<string, Entry> };
const manifest = (): Record<string, Entry> => (g.__pbImages ??= existsSync(FILE) ? JSON.parse(readFileSync(FILE, "utf8")) : {});
/** Manifest entries whose files are actually available (see mirrored()). */
export const imageManifest = () => Object.fromEntries(Object.entries(manifest()).filter(([id, m]) => deployed(id, m)));

export interface Mirrored { id: string; w: number; h: number }

/**
 * When images are served from public/ (IMAGE_BASE is a path), only trust the
 * manifest for files that were actually deployed: a host that builds from git
 * (Vercel, Netlify) has the manifest but not the files, and must show
 * placeholders rather than 404s. With a bucket/CDN origin, only entries the
 * mirror script marked as uploaded count.
 */
const localDir = IMAGE_BASE.startsWith("/") ? path.join(process.cwd(), "public", IMAGE_BASE) : null;
const present = new Map<string, boolean>();
const deployed = (id: string, m: Entry) => {
  if (!localDir) return m[3] === 1;
  let ok = present.get(id);
  if (ok === undefined) present.set(id, (ok = existsSync(path.join(localDir, `${id}.webp`))));
  return ok;
};

export function mirrored(storeUrl: string | null): Mirrored | null {
  const id = imageId(storeUrl);
  const m = id ? manifest()[id] : undefined;
  return id && m && deployed(id, m) ? { id, w: m[0], h: m[1] } : null;
}

/** Absolute URL of our full-size copy, for og:image and JSON-LD. */
export function absoluteImage(m: Mirrored) {
  const base = IMAGE_BASE.startsWith("http") ? IMAGE_BASE : SITE_URL + IMAGE_BASE;
  return `${base}/${m.id}.webp`;
}
