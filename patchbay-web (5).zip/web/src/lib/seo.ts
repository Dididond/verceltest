import type { Metadata } from "next";
import { absoluteImage, mirrored } from "./data/images";
import type { Card } from "./data/types";
import { BRAND, SITE_URL } from "./site";

export const absUrl = (p: string) => SITE_URL + (p.startsWith("/") ? p : "/" + p);

/**
 * The catalog's absolute URLs (canonicals, og:url, JSON-LD ids, breadcrumbs)
 * are written for production. Serve them from whichever origin this build is
 * for, so a staging copy is self-consistent. A no-op on pluginhood.com.
 */
const DATA_ORIGIN = "https://pluginhood.com";
export const rehost = (u: string) => (u.startsWith(DATA_ORIGIN) ? SITE_URL + u.slice(DATA_ORIGIN.length) : u);
export const rehostDeep = <T,>(o: T): T => (SITE_URL === DATA_ORIGIN ? o : (JSON.parse(JSON.stringify(o).split(DATA_ORIGIN).join(SITE_URL)) as T));

const LOCALE = "en_US";
/** Branded fallback share image (app/opengraph-image.tsx). */
const DEFAULT_OG = { url: "/opengraph-image", width: 1200, height: 630, alt: `${BRAND} — audio plugins and presets compared` };

/** Turns an absolute pluginhood.com URL into an internal path. */
export const toPath = (url: string) => {
  try { const u = new URL(url); return u.pathname + u.search; } catch { return url; }
};

function parseRobots(r: string | undefined): Metadata["robots"] {
  const v = (r ?? "index,follow").toLowerCase();
  return { index: !v.includes("noindex"), follow: !v.includes("nofollow") };
}

/** Product pages use the card's meta exactly. og:type=product is emitted by the page itself. */
export function cardMetadata(c: Card): Metadata {
  const m = c.meta;
  // Share images come from our mirror; the store's CDN URL is never emitted.
  const img = mirrored(c.product.image_url);
  const ogImage = img ? [{ url: absoluteImage(img), width: img.w, height: img.h, alt: c.content?.image_alt ?? c.product.name }] : [DEFAULT_OG];
  return {
    title: { absolute: m.title },
    description: m.description,
    alternates: { canonical: rehost(m.canonical) },
    robots: parseRobots(m.robots),
    openGraph: {
      title: m["og:title"] ?? m.title,
      description: m["og:description"] ?? m.description,
      url: rehost(m["og:url"] ?? m.canonical),
      siteName: m["og:site_name"] ?? BRAND,
      locale: LOCALE,
      images: ogImage,
    },
    twitter: {
      card: (m["twitter:card"] as "summary_large_image") ?? "summary_large_image",
      title: m["twitter:title"] ?? m.title,
      description: m["twitter:description"] ?? m.description,
      images: [ogImage[0].url],
    },
  };
}

/** Listing pages: self-canonical, with page 2+ titled and canonicalised separately. */
export function listingMetadata(o: { title: string; description: string; path: string; page?: number; noindex?: boolean }): Metadata {
  const page = o.page ?? 1;
  const path = page > 1 ? `${o.path === "/" ? "" : o.path}/page/${page}` : o.path;
  const title = page > 1 ? `${o.title} – Page ${page}` : o.title;
  const description = page > 1 ? `${o.description} Page ${page}.` : o.description;
  return {
    title,
    description,
    alternates: { canonical: absUrl(path) },
    robots: o.noindex ? { index: false, follow: true } : { index: true, follow: true },
    openGraph: { title: `${title} — ${BRAND}`, description, url: absUrl(path), siteName: BRAND, type: "website", locale: LOCALE, images: [DEFAULT_OG] },
    twitter: { card: "summary_large_image", title: `${title} — ${BRAND}`, description, images: [DEFAULT_OG.url] },
  };
}

/** Serialises JSON-LD safely for an inline <script>. */
export const jsonLd = (o: unknown) => JSON.stringify(o).replace(/</g, "\\u003c");

// ---------- Site-level structured data ----------

export const organizationLd = () => ({
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": `${SITE_URL}/#organization`,
  name: BRAND,
  url: SITE_URL + "/",
  logo: { "@type": "ImageObject", url: `${SITE_URL}/apple-icon`, width: 180, height: 180 },
});

export const websiteLd = (description: string) => ({
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": `${SITE_URL}/#website`,
  name: BRAND,
  url: SITE_URL + "/",
  description,
  inLanguage: "en",
  publisher: { "@id": `${SITE_URL}/#organization` },
  potentialAction: {
    "@type": "SearchAction",
    target: { "@type": "EntryPoint", urlTemplate: `${SITE_URL}/browse?q={search_term_string}` },
    "query-input": "required name=search_term_string",
  },
});

/** CollectionPage + ItemList for a listing page's visible products. */
export const collectionLd = (o: { name: string; description: string; path: string; items: { n: string; p: string }[]; offset?: number }) => ({
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  name: o.name,
  description: o.description,
  url: absUrl(o.path),
  isPartOf: { "@id": `${SITE_URL}/#website` },
  mainEntity: {
    "@type": "ItemList",
    itemListElement: o.items.map((i, k) => ({ "@type": "ListItem", position: (o.offset ?? 0) + k + 1, url: absUrl(i.p), name: i.n })),
  },
});
