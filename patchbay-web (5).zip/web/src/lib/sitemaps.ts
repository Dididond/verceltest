import "server-only";
import { getAllCards, getCategories, getDevelopers, getRequiresList } from "./data/catalog";
import { absoluteImage, mirrored } from "./data/images";
import { MIN_INDEXABLE_ITEMS } from "./listings";
import { absUrl, rehost } from "./seo";

/**
 * Sitemaps are split by kind so Search Console / Bing Webmaster report
 * indexing per section. Only indexable URLs are listed: no noindex variants,
 * no flagged cards, no thin listings, no filtered /browse URLs. No <lastmod>:
 * the catalog has no reliable modification dates and a fake one is ignored.
 */
export const SITEMAPS = ["pages", "plugins", "presets"] as const;
export type SitemapName = (typeof SITEMAPS)[number];

interface Entry { loc: string; image?: { loc: string; title: string } }

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");

export function entries(name: SitemapName): Entry[] {
  if (name === "pages") {
    const listing = (f: { path: string; count: number }) => (f.count >= MIN_INDEXABLE_ITEMS ? [{ loc: absUrl(f.path) }] : []);
    return [
      ...["/", "/plugins", "/presets", "/browse", "/developers"].map((p) => ({ loc: absUrl(p) })),
      ...getCategories().flatMap(listing),
      ...getRequiresList().flatMap(listing),
      ...getDevelopers().flatMap(listing),
    ];
  }
  const type = name === "plugins" ? "plugin" : "preset";
  return getAllCards()
    .filter((c) => c.indexable && c.product.product_type === type)
    .map((c) => {
      const img = mirrored(c.product.image_url);
      return { loc: rehost(c.meta.canonical || c.url), image: img ? { loc: absoluteImage(img), title: c.content?.image_alt ?? c.product.name } : undefined };
    });
}

export function urlset(list: Entry[]) {
  const body = list
    .map((e) => `<url><loc>${esc(e.loc)}</loc>${e.image ? `<image:image><image:loc>${esc(e.image.loc)}</image:loc><image:title>${esc(e.image.title)}</image:title></image:image>` : ""}</url>`)
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n${body}\n</urlset>\n`;
}

export function sitemapIndex() {
  const items = SITEMAPS.map((n) => `<sitemap><loc>${absUrl(`/sitemaps/${n}.xml`)}</loc></sitemap>`).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${items}\n</sitemapindex>\n`;
}

export const xml = (body: string) => new Response(body, { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } });
