"use client";

import { useEffect, useState } from "react";

export type Theme = "dark" | "light";
const KEY = "pb-theme";

/** Inline in <head> so the stored theme applies before first paint. */
export const THEME_BOOT = `try{var t=localStorage.getItem("${KEY}");if(t==="light"||t==="dark")document.documentElement.dataset.theme=t}catch(e){}`;

export function getTheme(): Theme {
  return document.documentElement.dataset.theme === "light" ? "light" : "dark";
}

export function toggleTheme() {
  const next: Theme = getTheme() === "light" ? "dark" : "light";
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem(KEY, next); } catch {}
}

export interface CanvasColors { acc: string; ink: string; ink3: string }

const read = (): CanvasColors => {
  const cs = getComputedStyle(document.documentElement);
  return { acc: cs.getPropertyValue("--acc").trim(), ink: cs.getPropertyValue("--ink").trim(), ink3: cs.getPropertyValue("--ink3").trim() };
};

/** Resolved token colours for canvas drawing; refreshes when the theme flips. */
export function useCanvasColors() {
  const [colors, setColors] = useState<CanvasColors>({ acc: "oklch(0.74 0.19 52)", ink: "oklch(0.96 0.005 80)", ink3: "oklch(0.6 0.008 80)" });
  useEffect(() => {
    setColors(read());
    const mo = new MutationObserver(() => setColors(read()));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => mo.disconnect();
  }, []);
  return colors;
}
