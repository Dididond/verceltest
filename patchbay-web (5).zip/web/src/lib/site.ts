// Working name — swap here to rebrand the whole site.
export const BRAND = "Patchbay";

/** Production origin; canonicals and the sitemap use it. */
export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "https://pluginhood.com").replace(/\/$/, "");
export const STORE_NAME = "Plugin Boutique";

export const EASE = {
  spring: "cubic-bezier(.2,1.25,.35,1)",
  outExpo: "cubic-bezier(.16,1,.3,1)",
};

export function prefersReducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** CSS zoom applied to <html> on wide screens (see globals.css). */
export function pageZoom(): number {
  if (typeof window === "undefined") return 1;
  return parseFloat(getComputedStyle(document.documentElement).zoom) || 1;
}
